import React, { useState, useEffect, useRef, useMemo } from "react";
import { 
  Moon, 
  CloudRain, 
  Compass, 
  Wind, 
  Star, 
  Shield, 
  Sparkles, 
  Heart, 
  BookOpen, 
  Sliders, 
  ChevronRight, 
  Send, 
  Plus, 
  Trash2, 
  Mic, 
  MicOff, 
  Volume2, 
  VolumeX, 
  Bell, 
  Flame, 
  Sun, 
  AlertCircle,
  Activity,
  RotateCcw,
  CheckCircle2,
  LogOut,
  User,
  Zap,
  Search,
  Bookmark,
  ChevronDown,
  ChevronUp,
  ArrowDown,
  Calendar,
  Pin
} from "lucide-react";
import { ChatMessage, JournalEntry, AmbientMode } from "./types";
import AmbientBackground from "./components/AmbientBackground";
import EmergencyOverlay from "./components/EmergencyOverlay";
import HomeView from "./components/HomeView";
import AuthView from "./components/AuthView";

import { auth, db, handleFirestoreError, OperationType } from "./firebase";
import { onAuthStateChanged, signOut } from "firebase/auth";
import { 
  collection, 
  doc, 
  setDoc, 
  updateDoc, 
  deleteDoc, 
  onSnapshot 
} from "firebase/firestore";

// Initial set of chat messages to prep Brother's memory
const INITIAL_CHAT: ChatMessage[] = [
  {
    id: "init_1",
    role: "assistant",
    text: "hey, man. i'm right here. no expectations, no quotas, and no judgment. tell me what's actually making today heavy for you.",
    timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    isStreamingComplete: true
  }
];

export default function App() {
  // Authentication & State Synced across Firebase
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [authChecking, setAuthChecking] = useState<boolean>(true);
  const [inAppStore, setInAppStore] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<string>("home"); // home | brother | journal | shield | journey | settings
  
  // Real Local & Firebase synced settings
  const [username, setUsername] = useState<string>("brother");
  const [ambientMode, setAmbientMode] = useState<AmbientMode>("Midnight");
  const [theme, setTheme] = useState<"dark" | "light">("dark");
  const [isNightAtmosphere, setIsNightAtmosphere] = useState<boolean>(true);
  
  // Emergency Mode Global Controls
  const [isEmergencyActive, setIsEmergencyActive] = useState<boolean>(false);
  
  // Mood Tracker State
  const [moodValue, setMoodValue] = useState<string>("");

  // Chat State
  const [chatInput, setChatInput] = useState("");
  const [chatHistory, setChatHistory] = useState<ChatMessage[]>(INITIAL_CHAT);
  const [isAiTyping, setIsAiTyping] = useState(false);
  const chatBottomRef = useRef<HTMLDivElement>(null);
  const chatScrollContainerRef = useRef<HTMLDivElement>(null);

  // ChatGPT multi-session threads
  const [activeThreadId, setActiveThreadId] = useState<string>("default_thread");
  const [editingThreadId, setEditingThreadId] = useState<string | null>(null);
  const [editingThreadTitleText, setEditingThreadTitleText] = useState<string>("");
  const [isSidebarOpen, setIsSidebarOpen] = useState<boolean>(false);

  // Compute active chat thread list dynamically
  const chatThreads = useMemo(() => {
    const list: { id: string; title: string; timestamp: number }[] = [];
    const seen = new Set<string>();

    chatHistory.forEach(m => {
      const tid = m.threadId || "default_thread";
      if (!seen.has(tid)) {
        seen.add(tid);
        // Find title
        let title = m.threadTitle || (tid === "default_thread" ? "First Sitting with Brother" : "Unnamed Chat");
        
        // If thread title is empty or default, derive from first user message if possible
        if (!m.threadTitle || m.threadTitle === "Unnamed Chat" || m.threadTitle === "New chat session") {
          const threadMsgs = chatHistory.filter(x => (x.threadId || "default_thread") === tid);
          const firstUserMsg = threadMsgs.find(x => x.role === "user");
          if (firstUserMsg) {
            title = firstUserMsg.text.slice(0, 26) + (firstUserMsg.text.length > 26 ? "..." : "");
          }
        }

        // Parse numerical timestamp
        const tNum = m.id.includes("_") ? parseInt(m.id.split("_")[0]) : Date.now();
        list.push({ id: tid, title, timestamp: tNum });
      }
    });

    // If default_thread is not in the list, make sure it exists
    if (!seen.has("default_thread")) {
      list.push({ id: "default_thread", title: "First Sitting with Brother", timestamp: 0 });
    }

    return list.sort((a, b) => b.timestamp - a.timestamp);
  }, [chatHistory]);
  
  // Custom Long-Term Memory & Search States
  const [chatSearchQuery, setChatSearchQuery] = useState("");
  const [isChatSearchOpen, setIsChatSearchOpen] = useState(false);
  const [showJumpToBottom, setShowJumpToBottom] = useState(false);
  const [activePinMsgId, setActivePinMsgId] = useState<string | null>(null);
  const [isMemoryFilterActive, setIsMemoryFilterActive] = useState<"all" | "short" | "medium" | "long" | "pinned" | null>(null);

  // Journal State
  const [journalContent, setJournalContent] = useState("");
  const [selectedMood, setSelectedMood] = useState<JournalEntry["mood"]>("heavy");
  const [journalTagsInput, setJournalTagsInput] = useState("");
  const [journals, setJournals] = useState<JournalEntry[]>([]);
  const [isVoiceRecording, setIsVoiceRecording] = useState(false);
  const [voiceTimer, setVoiceTimer] = useState(0);
  const voiceIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const [journalSummary, setJournalSummary] = useState<string>("");
  const [isSummarizingJournal, setIsSummarizingJournal] = useState(false);

  // Survival View States (Now in Shield Tab)
  const [coldTimer, setColdTimer] = useState(180); // 3 minutes cold shower
  const [isColdActive, setIsColdActive] = useState(false);
  const [walkBeat, setWalkBeat] = useState<"left" | "right">("left");
  const [isWalkActive, setIsWalkActive] = useState(false);

  // Growth metric stats
  const [urgesSurvived, setUrgesSurvived] = useState<number>(4);
  const [honestyCount, setHonestyCount] = useState<number>(2);
  const [recoveryDays, setRecoveryDays] = useState<number>(3);
  const [honestyStreak, setHonestyStreak] = useState<number>(4);
  const [consistency, setConsistency] = useState<number>(95);
  const [isChatImmersionMode, setIsChatImmersionMode] = useState<boolean>(false);
  const [isRelapseResetPlaying, setIsRelapseResetPlaying] = useState<boolean>(false);

  // Safe Push Notifications Simulation Space
  const [notifications, setNotifications] = useState<{ id: string; text: string; time: string }[]>([]);

  // Automatically compute Night Atmosphere (10PM - 6AM) state
  useEffect(() => {
    const checkNighttime = () => {
      const hour = new Date().getHours();
      const computedNight = hour >= 22 || hour < 6;
      setIsNightAtmosphere(computedNight);
    };
    checkNighttime();
    const interval = setInterval(checkNighttime, 60000);
    return () => clearInterval(interval);
  }, []);

  // Auth checking timeout fallback to prevent infinite spinner under any condition
  useEffect(() => {
    if (authChecking) {
      const timer = setTimeout(() => {
        console.warn("Auth initialization timed out. Forcing unblock.");
        setAuthChecking(false);
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [authChecking]);

  // Set up Firebase Authentication listener
  useEffect(() => {
    setAuthChecking(true);
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      if (user) {
        setCurrentUser(user);
        setInAppStore(true);
      } else {
        setCurrentUser(null);
        setInAppStore(false);
      }
      setAuthChecking(false);
    }, (err) => {
      console.error("onAuthStateChanged error:", err);
      setAuthChecking(false);
    });
    return () => unsubscribe();
  }, []);

  // Listen to real-time changes in User's collections whenever currentUser references change
  useEffect(() => {
    if (!currentUser) {
      setChatHistory(INITIAL_CHAT);
      setJournals([]);
      return;
    }

    const userId = currentUser.uid;

    // 1. Listen to real-time changes in User's main document profile
    const userRef = doc(db, "users", userId);

    const unsubscribeUser = onSnapshot(userRef, async (docSnap) => {
      if (docSnap.exists()) {
        const data = docSnap.data();
        if (data.username) setUsername(data.username);
        if (data.ambientMode) setAmbientMode(data.ambientMode as AmbientMode);
        if (data.theme) setTheme(data.theme as "dark" | "light");
        if (data.urgesSurvived !== undefined) setUrgesSurvived(data.urgesSurvived);
        if (data.honestyCount !== undefined) setHonestyCount(data.honestyCount);
        if (data.memorySummary !== undefined) setJournalSummary(data.memorySummary);
        if (data.recoveryDays !== undefined) setRecoveryDays(data.recoveryDays);
        if (data.honestyStreak !== undefined) setHonestyStreak(data.honestyStreak);
        if (data.consistency !== undefined) setConsistency(data.consistency);
      } else {
        // Document doesn't exist yet but user is authenticated. Let's auto-create details.
        try {
          console.log("No user profile found, auto-initializing document in Firestore.");
          const emailPrefix = currentUser.email?.split("@")[0] || "brother";
          await setDoc(userRef, {
            username: username || emailPrefix,
            ambientMode: ambientMode || "Midnight",
            theme: theme || "dark",
            urgesSurvived: urgesSurvived !== undefined ? urgesSurvived : 4,
            honestyCount: honestyCount !== undefined ? honestyCount : 2,
            recoveryDays: recoveryDays !== undefined ? recoveryDays : 3,
            honestyStreak: honestyStreak !== undefined ? honestyStreak : 4,
            consistency: consistency !== undefined ? consistency : 95,
            memorySummary: "User joined the circle tonight.",
            createdAt: new Date().toISOString()
          }, { merge: true });
        } catch (initErr) {
          console.error("Failed to auto-create missing user profile document:", initErr);
        }
      }
    }, (err) => {
      console.error("User profile snapshot stream error: ", err);
    });

    // 2. Listen to real-time changes in User's chats history
    const chatsRef = collection(db, "users", userId, "chats");
    const unsubscribeChats = onSnapshot(chatsRef, (snapshot) => {
      const fetchedChats: ChatMessage[] = [];
      snapshot.forEach((doc) => {
        fetchedChats.push({ id: doc.id, ...doc.data() } as ChatMessage);
      });
      
      // Sort messages chronologically by timestamp
      fetchedChats.sort((a, b) => {
        const timeA = a.id.includes("_") ? parseInt(a.id.split("_")[0]) : 0;
        const timeB = b.id.includes("_") ? parseInt(b.id.split("_")[0]) : 0;
        return timeA - timeB;
      });

      if (fetchedChats.length === 0) {
        setChatHistory(INITIAL_CHAT);
      } else {
        setChatHistory(fetchedChats);
      }
    }, (err) => {
      console.error("Chat snapshot stream error: ", err);
    });

    // 3. Listen to real-time changes in User's journals collection
    const journalsRef = collection(db, "users", userId, "journals");
    const unsubscribeJournals = onSnapshot(journalsRef, (snapshot) => {
      const fetchedJournals: JournalEntry[] = [];
      snapshot.forEach((doc) => {
        fetchedJournals.push({ id: doc.id, ...doc.data() } as JournalEntry);
      });

      // Sort journals descending (newest first)
      fetchedJournals.sort((a, b) => b.timestamp - a.timestamp);
      setJournals(fetchedJournals);
    }, (err) => {
      console.error("Journals snapshot stream error: ", err);
    });

    return () => {
      unsubscribeUser();
      unsubscribeChats();
      unsubscribeJournals();
    };
  }, [currentUser]);

  // Update specific single field in user profile helper
  const updateUserProfileValue = async (fields: Partial<any>) => {
    if (!auth.currentUser) return;
    try {
      const userRef = doc(db, "users", auth.currentUser.uid);
      await updateDoc(userRef, fields);
    } catch (err) {
      // Create user doc if it doesn't exist yet but user is logged in
      try {
        const userRef = doc(db, "users", auth.currentUser!.uid);
        await setDoc(userRef, {
          username,
          ambientMode,
          theme,
          urgesSurvived,
          honestyCount,
          recoveryDays,
          honestyStreak,
          consistency,
          memorySummary: journalSummary || "Active member.",
          ...fields
        }, { merge: true });
      } catch (innerErr) {
        handleFirestoreError(innerErr, OperationType.UPDATE, `users/${auth.currentUser?.uid}`);
      }
    }
  };

  // Scroll Chat to bottom
  useEffect(() => {
    chatBottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [chatHistory, isAiTyping]);

  // Handle billing walk simulator metronome pulses
  useEffect(() => {
    let interval: any;
    if (isWalkActive) {
      interval = setInterval(() => {
        setWalkBeat((prev) => (prev === "left" ? "right" : "left"));
      }, 3000);
    }
    return () => clearInterval(interval);
  }, [isWalkActive]);

  // Cold shower stopwatch
  useEffect(() => {
    let interval: any;
    if (isColdActive && coldTimer > 0) {
      interval = setInterval(() => {
        setColdTimer((prev) => prev - 1);
      }, 1000);
    } else if (coldTimer === 0) {
      setIsColdActive(false);
      triggerSafeNotification("Shower complete. Excellent work showing grit tonight.");
    }
    return () => clearInterval(interval);
  }, [isColdActive, coldTimer]);

  // Simulated Voice Recorder timer
  const startRecordingSim = () => {
    setIsVoiceRecording(true);
    setVoiceTimer(0);
    voiceIntervalRef.current = setInterval(() => {
      setVoiceTimer((t) => t + 1);
    }, 1000);
  };

  const stopRecordingSimAndFill = () => {
    if (voiceIntervalRef.current) {
      clearInterval(voiceIntervalRef.current);
    }
    setIsVoiceRecording(false);
    setJournalContent(
      (prev) => 
        prev + " (Spoken voice transcript: I am feeling extremely isolated tonight, like there's a heavy lead block sitting inside my stomach. I wanted to numb out, but I chose to sit down, press record, and speak instead.)"
    );
  };

  // Safe Atmospheric Web Push Notification test simulations
  const triggerSafeNotification = (text: string) => {
    const id = Date.now().toString();
    const newNotif = {
      id,
      text,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };
    setNotifications((prev) => [newNotif, ...prev]);
    
    // Auto clear notification after 8 seconds fade
    setTimeout(() => {
      setNotifications((prev) => prev.filter((n) => n.id !== id));
    }, 8000);
  };

  const triggerRandomSafeNotification = () => {
    const alerts = [
      "brother: you've been quiet for a couple hours. just wanted to check if you're taking deep, real breaths.",
      "brother: the wind outside is howling, but your shelter is quiet and secure. don't look back at the feeds.",
      "brother: the urge is just an emotional wave. let it wash across the sandy coast and flow out.",
      "brother: if your eyes are exhausted from the glowing panels, shut it down. i'll stay awake, go sleep.",
      "brother: no metrics tonight. no expectations. you are doing perfectly fine just sitting here."
    ];
    const picked = alerts[Math.floor(Math.random() * alerts.length)];
    triggerSafeNotification(picked);
  };

  // Long-Term Companion Memory & Advanced Scroll Logic
  const handleChatScroll = (e: React.UIEvent<HTMLDivElement>) => {
    const target = e.currentTarget;
    const offsetFromBottom = target.scrollHeight - target.scrollTop - target.clientHeight;
    // Show button if user scrolled up more than 150px
    if (offsetFromBottom > 150) {
      setShowJumpToBottom(true);
    } else {
      setShowJumpToBottom(false);
    }
  };

  const jumpToBottom = () => {
    chatBottomRef.current?.scrollIntoView({ behavior: "smooth" });
    setShowJumpToBottom(false);
  };

  const togglePinMessage = async (messageId: string, memoryType: "short" | "medium" | "long" = "short") => {
    if (!currentUser) return;
    const msg = chatHistory.find(m => m.id === messageId);
    if (!msg) return;

    const isCurrentPinned = msg.isPinned || false;
    const newPinned = !isCurrentPinned;

    try {
      const msgRef = doc(db, "users", currentUser.uid, "chats", messageId);
      await updateDoc(msgRef, {
        isPinned: newPinned,
        memoryType: newPinned ? memoryType : null,
        pinnedAt: newPinned ? new Date().toISOString() : null
      });
      setActivePinMsgId(null);
      triggerSafeNotification(newPinned ? "Moment archived in Brother's memory" : "Moment removed from companion vault");
    } catch (err) {
      console.error("Error persistent pinning message:", err);
    }
  };

  // Firebase Firestore actions for Chat messages
  const handleChatSend = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!chatInput.trim() || !currentUser) return;

    const userText = chatInput.trim();
    const timestampStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const chatId = Date.now().toString() + "_u";

    // Compute or find the thread title
    const activeChatsList = chatHistory.filter((m) => (m.threadId || "default_thread") === activeThreadId);
    const existingTitle = activeChatsList.find(m => m.threadTitle && m.threadTitle !== "New Sitting Room")?.threadTitle || "";
    const computedTitle = existingTitle || (userText.slice(0, 30) + (userText.length > 30 ? "..." : ""));

    const userMsg: ChatMessage = {
      id: chatId,
      role: "user",
      text: userText,
      timestamp: timestampStr,
      isStreamingComplete: true,
      threadId: activeThreadId,
      threadTitle: computedTitle
    };

    // 1. Instantly save User Message directly into Firestore sub-collection
    try {
      const msgRef = doc(db, "users", currentUser.uid, "chats", chatId);
      await setDoc(msgRef, userMsg);
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `users/${currentUser?.uid}/chats/${chatId}`);
    }

    setChatInput("");
    setIsAiTyping(true);

    // AI memory evaluation logic context
    const memorySummaryStr = `User struggles with mood '${moodValue || "unspecified"}'. Survived ${urgesSurvived} difficult nights. Username is ${username}. Previous memory summary: ${journalSummary}`;
    let lastJournalInsight = journalSummary;

    // Collect pinned moments and compile memories
    const pinnedMoments = chatHistory.filter((m: any) => m.isPinned);
    const pinnedMemoriesText = pinnedMoments.map((m: any) => {
      const scaleLabel = m.memoryType === "long" ? "Long-term breakthrough" : m.memoryType === "medium" ? "Medium-term pattern" : "Short-term strain";
      return `- [${scaleLabel} (${m.timestamp})]: "${m.text}"`;
    }).join("\n");

    try {
      // Build correct context of active thread only
      const currentThreadMsgsForAI = [...activeChatsList, userMsg].slice(-10);

      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: currentThreadMsgsForAI, // only send active thread subset for pristine ChatGPT isolation!
          memorySummary: memorySummaryStr,
          ambientMode,
          isNight: isNightAtmosphere,
          journalInsight: lastJournalInsight,
          pinnedMemories: pinnedMemoriesText,
        })
      });

      if (!response.ok) throw new Error("Brother Chat Connection Latency");

      const data = await response.json();
      const responseText = data.text;
      
      // 2. Clear real-time typing state, create streaming model draft
      setIsAiTyping(false);
      const aiMsgId = (Date.now() + 10).toString() + "_a";
      const aiMsg: ChatMessage = {
        id: aiMsgId,
        role: "assistant",
        text: "typing...",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        isStreamingComplete: false,
        threadId: activeThreadId,
        threadTitle: computedTitle
      };

      setChatHistory((prev) => [...prev, aiMsg]);
      
      // Buttery typewriter styling (slower nocturnal typing intervals matching mood pace)
      let index = 0;
      const tickSpeed = isNightAtmosphere ? 25 : 12; // slow down typing cadence at night
      const timer = setInterval(async () => {
        index += 2;
        if (index >= responseText.length) {
          clearInterval(timer);
          
          // Complete message assembly
          const finalMsg: ChatMessage = {
            id: aiMsgId,
            role: "assistant",
            text: responseText,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            isStreamingComplete: true,
            threadId: activeThreadId,
            threadTitle: computedTitle
          };

          // Save completed model message to Firestore to freeze logs eternally
          try {
            await setDoc(doc(db, "users", currentUser.uid, "chats", aiMsgId), finalMsg);
          } catch (dbErr) {
            console.error("Error saving completed bot chat message to firestore", dbErr);
          }
        } else {
          setChatHistory((prev) =>
            prev.map((msg) =>
              msg.id === aiMsgId
                ? { ...msg, text: responseText.slice(0, index) + "▊" }
                : msg
            )
          );
        }
      }, tickSpeed);

    } catch (err: any) {
      console.error("Chat client-backend error:", err);
      setIsAiTyping(false);
      
      const errorMsgId = Date.now().toString() + "_a";
      const errorMsg: ChatMessage = {
        id: errorMsgId,
        role: "assistant",
        text: "the midnight connection hummed out for a second. but i'm still here, man. take a slow deep breath.",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        isStreamingComplete: true,
        threadId: activeThreadId,
        threadTitle: computedTitle
      };

      setChatHistory((prev) => [...prev, errorMsg]);
    }
  };

  // Create a brand new sitting room conversation (ChatGPT thread)
  const handleAddNewThread = async () => {
    if (!currentUser) return;
    const newThreadId = "thread_" + Date.now();
    const newGreetingId = Date.now() + "_a";
    
    const newGreetingMsg: ChatMessage = {
      id: newGreetingId,
      role: "assistant",
      text: "hey, man. i'm right here. no expectations, no quotas, and no judgment. tell me what's actually making today heavy for you.",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      isStreamingComplete: true,
      threadId: newThreadId,
      threadTitle: "New Sitting Room"
    };

    try {
      await setDoc(doc(db, "users", currentUser.uid, "chats", newGreetingId), newGreetingMsg);
      setActiveThreadId(newThreadId);
      triggerSafeNotification("Entered a new sitting room");
    } catch (err) {
      console.error("Error creating new thread session greeting:", err);
    }
  };

  // Rename sitting room conversation title
  const renameThread = async (threadId: string, newTitle: string) => {
    if (!currentUser || !newTitle.trim()) return;
    try {
      const threadMsgs = chatHistory.filter((m) => (m.threadId || "default_thread") === threadId);
      for (const m of threadMsgs) {
        const msgRef = doc(db, "users", currentUser.uid, "chats", m.id);
        await updateDoc(msgRef, { threadTitle: newTitle });
      }
      setEditingThreadId(null);
      triggerSafeNotification("Sitting room renamed");
    } catch (err) {
      console.error("Error renaming thread messages:", err);
    }
  };

  // Delete/wipe sitting room conversation
  const deleteThread = async (threadId: string) => {
    if (!currentUser) return;
    if (confirm("Step out and sweep these conversation logs to ashes forever?")) {
      try {
        const threadMsgs = chatHistory.filter((m) => (m.threadId || "default_thread") === threadId);
        for (const m of threadMsgs) {
          const msgRef = doc(db, "users", currentUser.uid, "chats", m.id);
          await deleteDoc(msgRef);
        }
        
        // Find next remaining thread or set default
        const remainingThreads = chatThreads.filter(t => t.id !== threadId);
        if (remainingThreads.length > 0) {
          setActiveThreadId(remainingThreads[0].id);
        } else {
          setActiveThreadId("default_thread");
        }
        triggerSafeNotification("Session swept clean");
      } catch (err) {
        console.error("Error deleting thread logs:", err);
      }
    }
  };

  // Firebase Firestore actions for Journal Entries
  const handleSaveJournal = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!journalContent.trim() || !currentUser) return;

    const tagsArr = journalTagsInput
      .split(",")
      .map((t) => t.trim().toLowerCase())
      .filter((t) => t !== "");

    const journalId = Date.now().toString();
    const newJournal: JournalEntry = {
      id: journalId,
      content: journalContent,
      date: new Date().toLocaleDateString([], { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" }),
      mood: selectedMood,
      tags: tagsArr.length > 0 ? tagsArr : ["truth-seeking"],
      timestamp: Date.now()
    };

    try {
      await setDoc(doc(db, "users", currentUser.uid, "journals", journalId), newJournal);
      const newHonesty = honestyCount + 1;
      await updateUserProfileValue({ honestyCount: newHonesty });
      
      setJournalContent("");
      setJournalTagsInput("");
      triggerSafeNotification("Entry quietly locked inside safe storage. Thank you for your honesty.");
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `users/${currentUser?.uid}/journals/${journalId}`);
    }
  };

  const handleDeleteJournal = async (id: string) => {
    if (!currentUser) return;
    try {
      await deleteDoc(doc(db, "users", currentUser.uid, "journals", id));
      triggerSafeNotification("Entry removed safely.");
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `users/${currentUser?.uid}/journals/${id}`);
    }
  };

  // Summarize whole journal for emotional climate report via Backend
  const handleSummarizeJournals = async () => {
    if (journals.length === 0) {
      setJournalSummary("Write something in your journal sheets first, brother.");
      return;
    }
    setIsSummarizingJournal(true);
    try {
      const resp = await fetch("/api/summarize-journal", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ journalEntries: journals })
      });

      if (!resp.ok) throw new Error("Weather Report Engine Latency");

      const data = await resp.json();
      setJournalSummary(data.insight);
      
      // Persist poetic reflection permanently in Firestore user context
      await updateUserProfileValue({ memorySummary: data.insight });
      
    } catch (err) {
      setJournalSummary("the fog turned the weather glass opaque for a second. keep typing. your story is safe.");
    } finally {
      setIsSummarizingJournal(false);
    }
  };

  // Clear memory cache completely
  const handleClearCache = async () => {
    if (!currentUser) return;
    if (confirm("Reset conversation logs and memory sheets inside this profile? This will delete all stats, messages, and journals forever.")) {
      try {
        // We delete documents step-by-step
        for (const j of journals) {
          await deleteDoc(doc(db, "users", currentUser.uid, "journals", j.id));
        }
        for (const c of chatHistory) {
          if (c.id !== "init_1") {
            await deleteDoc(doc(db, "users", currentUser.uid, "chats", c.id));
          }
        }
        await updateUserProfileValue({
          urgesSurvived: 0,
          honestyCount: 0,
          memorySummary: "User wiped worksheets clean."
        });
        
        triggerSafeNotification("Hearth cleared back to pristine ashes.");
      } catch (err) {
        handleFirestoreError(err, OperationType.DELETE, `users/${currentUser.uid}`);
      }
    }
  };

  const handleLogout = async () => {
    if (confirm("Step out of the warm room for tonight? Your stories remain privately sealed.")) {
      try {
        await signOut(auth);
        setInAppStore(false);
        setChatHistory(INITIAL_CHAT);
        setJournals([]);
      } catch (err) {
        console.error("Logout failure:", err);
      }
    }
  };

  // Reset somatic shower stopwatch
  function _resetShowerSettings() {
    setColdTimer(180);
    setIsColdActive(false);
  }

  // Auth checking indicator loader
  if (authChecking) {
    return (
      <div className="min-h-screen w-full bg-[#030303] flex flex-col justify-center items-center space-y-4">
        <div className="relative w-12 h-12 flex items-center justify-center">
          <span className="absolute inset-0 rounded-2xl border-2 border-indigo-500/20 animate-[ping_2s_infinite]" />
          <span className="w-5 h-5 rounded-full border-2 border-indigo-400 border-t-transparent animate-spin" />
        </div>
        <div className="text-center space-y-1">
          <p className="text-xs font-mono tracking-widest text-indigo-400 uppercase">opening cabin doors</p>
          <p className="text-[10px] text-gray-500 font-mono">uncovering late night safety circle...</p>
        </div>
      </div>
    );
  }

  return (
    <div className={`min-h-[100dvh] transition-colors duration-1000 overflow-x-hidden ${theme === "light" ? "bg-[#efece6] text-[#2c2a29]" : "bg-[#030305] text-[#e0e3eb]"}`}>
      
      {/* Immersive cinematic weather overlay controls */}
      <AmbientBackground mode={ambientMode} isLightMode={theme === "light"} isNightAtmosphere={isNightAtmosphere} />

      {/* Healing environment progression: warmth, sunrise glows if present count increases */}
      {recoveryDays >= 5 && (
        <div className="fixed inset-0 pointer-events-none z-[-45] bg-[radial-gradient(circle_at_bottom_right,_rgba(251,191,36,0.06),_transparent_65%)] animate-pulse duration-[10000ms]" />
      )}
      {recoveryDays >= 8 && (
        <div className="fixed inset-0 pointer-events-none z-[-44] bg-[radial-gradient(circle_at_top_left,_rgba(14,165,233,0.04),_transparent_55%)]" />
      )}
      
      {/* If a relapse sequence is currently triggered, darken the backdrop with a heavy muzzy look */}
      {isRelapseResetPlaying && (
        <div className="fixed inset-0 pointer-events-none z-[-42] bg-[#0c0f17]/45 backdrop-blur-xs transition-all duration-1000 animate-fadeIn" />
      )}

      {/* Atmospheric dynamic push-style simulation banner triggers */}
      <div className="fixed top-4 right-4 z-50 pointer-events-none max-w-sm w-full space-y-2">
        {notifications.map((n) => (
          <div key={n.id} className="pointer-events-auto p-4 rounded-xl glass-panel border border-indigo-500/20 bg-black/75 backdrop-blur-3xl text-xs text-indigo-300 leading-normal flex items-start space-x-2.5 animate-[fadeIn_0.4s_ease-out] shadow-2xl">
            <span className="p-1 rounded-full bg-indigo-500/10 text-indigo-400 flex-shrink-0 animate-pulse mt-0.5">
              <Bell size={12} />
            </span>
            <div className="space-y-1 flex-1">
              <p className="font-mono text-[9px] uppercase tracking-wider text-indigo-400/80">Message dispatch • {n.time}</p>
              <p className="text-[#ededf3] leading-relaxed select-none">{n.text}</p>
            </div>
          </div>
        ))}
      </div>

      {/* 1. UNAUTHENTICATED ENCYCLOPEDIA AUTH VIEW */}
      {!currentUser && !authChecking ? (
        <AuthView 
          onAuthSuccess={(uid, profile) => {
            setCurrentUser({ uid });
            setInAppStore(true);
          }} 
        />
      ) : (

        /* 2. PROTECTED LOGGED IN LANDING/DASHBOARD CONTAINER */
        <div className={`relative h-[100dvh] flex flex-col overflow-hidden transition-all duration-300 ${isChatImmersionMode && activeTab === "brother" ? "pt-0 pb-0" : "pt-3 pb-20"}`}>
          
          {/* Global Header Brand with profile and logout toggler */}
          {!(isChatImmersionMode && activeTab === "brother") && (
            <header className={`w-full max-w-4xl mx-auto px-4 md:px-6 flex justify-between items-center pb-3 border-b ${theme === 'light' ? 'border-neutral-200' : 'border-white/5'} z-20 select-none shrink-0`}>
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-purple-600 to-indigo-600 flex items-center justify-center font-bold tracking-tighter text-white mr-1 text-sm">
                  B
                </div>
                <div>
                  <span className={`text-[10px] font-mono tracking-wider opacity-60 uppercase block`}>Safe Space Circle</span>
                  <span className="text-xs font-semibold tracking-tight">Stay present, man.</span>
                </div>
              </div>

              {/* Profile Info & Logout */}
              <div className="flex items-center space-x-3">
                <div className={`px-3 py-1.5 rounded-full border ${theme === 'light' ? 'border-neutral-200 bg-neutral-100' : 'border-white/5 bg-white/[0.02]'} flex items-center space-x-2 text-xs text-gray-400`}>
                  <User size={12} className="text-indigo-400" />
                  <span className="font-mono tracking-tight text-white max-w-[80px] truncate">{username}</span>
                </div>
                <button
                  onClick={handleLogout}
                  className={`p-2 rounded-full border transition-all ${theme === 'light' ? 'border-neutral-200 bg-neutral-100 text-neutral-600 hover:bg-neutral-200' : 'border-white/5 bg-white/[0.02] text-gray-400 hover:bg-white/10 hover:text-white'} cursor-pointer`}
                  title="Leave Sanctuary"
                >
                  <LogOut size={13} />
                </button>
              </div>
            </header>
          )}

          {/* Core Content Navigation Routing Sheets */}
          <main className={`flex-1 w-full relative focus-panel overflow-hidden flex flex-col min-h-0 transition-all duration-300 ${isChatImmersionMode && activeTab === "brother" ? "max-w-none px-0 mt-0" : "max-w-4xl mx-auto px-4 md:px-6 mt-4"}`}>
            
            {/* 1. HOME VIEW */}
            {activeTab === "home" && (
              <div className="flex-1 overflow-y-auto overscroll-contain no-scrollbar pr-1 pb-24 space-y-6">
                <HomeView 
                  username={username}
                  isNight={isNightAtmosphere}
                  ambientMode={ambientMode}
                  setAmbientMode={handleAmbientChange}
                  onNavigateToTab={(t) => setActiveTab(t)}
                  onTriggerEmergency={() => setActiveTab("shield")}
                  moodValue={moodValue}
                  setMoodValue={setMoodValue}
                />
              </div>
            )}

            {/* 2. BROTHER COMPANION CHAT VIEW */}
            {activeTab === "brother" && (
              <div className={`flex-1 flex flex-col md:flex-row gap-3 md:gap-4 overflow-hidden relative text-slate-200 transition-all duration-300 ${isChatImmersionMode ? "h-[100dvh] w-full max-w-full p-4 lg:p-6 bg-black/[0.05] border-0" : "h-full pt-1 pb-16"}`}>
                
                {/* 2A. LEFT COLUMN: CHAT SIDEBAR/DRAWER (DESKTOP CONSTANT, MOBILE TOGGLE SLIDE-IN) */}
                <div className={`
                  ${isSidebarOpen ? "translate-x-0 opacity-100 z-40" : "-translate-x-full lg:translate-x-0 opacity-0 lg:opacity-100 -z-10 lg:z-10 hidden lg:flex"}
                  transition-all duration-300 absolute lg:static left-0 top-0 bottom-0 w-72 lg:w-64 max-w-full bg-[#030305] lg:bg-white/[0.01] border lg:border-r border-white/5 p-4 rounded-3xl flex flex-col space-y-4 shrink-0 shadow-2xl h-full backdrop-blur-2xl lg:backdrop-blur-none
                `}>
                  {/* Sidebar Header */}
                  <div className="flex items-center justify-between border-b border-white/5 pb-3 shrink-0">
                    <span className="text-xs font-mono text-gray-400 font-semibold tracking-wider uppercase flex items-center">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse mr-1.5" />
                      Sitting Rooms
                    </span>
                    <button 
                      onClick={handleAddNewThread}
                      className="p-1 px-2.5 bg-indigo-500/10 hover:bg-indigo-500/20 text-indigo-300 rounded-lg border border-indigo-500/20 text-[10px] font-mono flex items-center space-x-1 uppercase transition-all cursor-pointer"
                      title="Light a new fire in a new sitting room"
                    >
                      <Plus size={10} />
                      <span>New</span>
                    </button>
                  </div>

                  {/* Sidebar List Container */}
                  <div className="flex-1 overflow-y-auto pr-1 space-y-2 no-scrollbar">
                    {chatThreads.map((thread) => {
                      const isActive = thread.id === activeThreadId;
                      const isEditing = thread.id === editingThreadId;

                      return (
                        <div 
                          key={thread.id} 
                          onClick={() => {
                            if (!isEditing) {
                              setActiveThreadId(thread.id);
                              setIsSidebarOpen(false); // close sidebar on mobile tap
                            }
                          }}
                          className={`group relative p-2.5 rounded-xl border transition-all cursor-pointer flex items-center justify-between ${
                            isActive 
                              ? "bg-indigo-500/15 border-indigo-500/40 text-indigo-300 shadow-lg" 
                              : "bg-white/[0.01] hover:bg-white/[0.03] border-transparent text-gray-400 hover:text-gray-200"
                          }`}
                        >
                          <div className="flex items-center space-x-2.5 min-w-0 flex-grow pr-2">
                            {/* Simple message bubble indicator icon */}
                            <div className={`p-1.5 rounded-lg shrink-0 ${isActive ? "bg-indigo-500/25 text-indigo-300 animate-pulse" : "bg-white/5 text-gray-500"}`}>
                              <Sparkles size={11} />
                            </div>

                            {/* Thread Title Label or TextBox in Editing Mode */}
                            <div className="min-w-0 flex-1">
                              {isEditing ? (
                                <input 
                                  type="text"
                                  value={editingThreadTitleText}
                                  onChange={(e) => setEditingThreadTitleText(e.target.value)}
                                  onKeyDown={(e) => {
                                    if (e.key === "Enter") {
                                      renameThread(thread.id, editingThreadTitleText);
                                    } else if (e.key === "Escape") {
                                      setEditingThreadId(null);
                                    }
                                  }}
                                  autoFocus
                                  className="w-full bg-black/80 border border-indigo-500/30 rounded px-1.5 py-0.5 text-xs text-white focus:outline-none"
                                  onClick={(e) => e.stopPropagation()}
                                />
                              ) : (
                                <p className="text-xs font-medium truncate tracking-tight">{thread.title}</p>
                              )}
                              <p className="text-[8px] font-mono opacity-50 mt-0.5">
                                {thread.id === "default_thread" ? "Original Cabin" : "Private Session"}
                              </p>
                            </div>
                          </div>

                          {/* Hover Actions: Rename and Delete */}
                          {!isEditing && (
                            <div className="flex items-center space-x-1 opacity-100 lg:opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap shrink-0">
                              <button 
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setEditingThreadId(thread.id);
                                  setEditingThreadTitleText(thread.title);
                                }}
                                className="p-1 hover:bg-white/5 text-gray-400 hover:text-white rounded transition-all"
                                title="Rename this room"
                              >
                                <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4Z"/></svg>
                              </button>
                              {thread.id !== "default_thread" && (
                                <button 
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    deleteThread(thread.id);
                                  }}
                                  className="p-1 hover:bg-rose-500/20 text-gray-400 hover:text-rose-400 rounded transition-all"
                                  title="Wipe logs"
                                >
                                  <Trash2 size={10} />
                                </button>
                              )}
                            </div>
                          )}

                          {/* Save renaming button inside editing state */}
                          {isEditing && (
                            <button 
                              onClick={(e) => {
                                e.stopPropagation();
                                renameThread(thread.id, editingThreadTitleText);
                              }}
                              className="p-1 bg-emerald-500/20 text-emerald-400 hover:bg-emerald-500/30 rounded ml-1 transition-all"
                            >
                              ✓
                            </button>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Mobile Drawer Overlay Backdrop */}
                {isSidebarOpen && (
                  <div 
                    onClick={() => setIsSidebarOpen(false)}
                    className="fixed inset-0 bg-black/60 backdrop-blur-xs z-30 lg:hidden"
                  />
                )}

                {/* 2B. RIGHT COLUMN: ACTIVE CONVERSATION WORKSPACE */}
                <div className="flex-1 flex flex-col h-full overflow-hidden relative">
                  
                  {/* RESTORATIVE HEALING METRIC PANEL */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-2 shrink-0 select-none animate-fadeIn">
                    
                    {/* Metric 1: Days Active */}
                    <div className="relative overflow-hidden bg-white/[0.01] border border-white/5 p-1.5 sm:p-2 rounded-xl flex items-center space-x-2 transition-all duration-300 hover:bg-white/[0.03]">
                      <span className="absolute right-0 bottom-0 w-8 h-8 rounded-full bg-amber-500/5 blur-xs pointer-events-none" />
                      <div className="w-6 h-6 rounded-lg bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 font-mono tracking-tight text-[10px] shrink-0 font-bold">
                        {recoveryDays}d
                      </div>
                      <div className="min-w-0 flex-1">
                        <span className="text-[7.5px] font-mono text-gray-400 uppercase tracking-widest block leading-none">Days Present</span>
                        <span className="text-[10px] font-medium text-amber-100 mt-0.5 block truncate">
                          Day {recoveryDays} of recovery
                        </span>
                      </div>
                    </div>

                    {/* Metric 2: Nights Survived */}
                    <div className="relative overflow-hidden bg-white/[0.01] border border-white/5 p-1.5 sm:p-2 rounded-xl flex items-center space-x-2 transition-all duration-300 hover:bg-white/[0.03]">
                      <span className="absolute right-0 bottom-0 w-8 h-8 rounded-full bg-emerald-500/5 blur-xs pointer-events-none" />
                      <div className="w-6 h-6 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 font-mono tracking-tight text-[10px] shrink-0 font-bold">
                        {urgesSurvived}n
                      </div>
                      <div className="min-w-0 flex-1">
                        <span className="text-[7.5px] font-mono text-gray-400 uppercase tracking-widest block leading-none">Nights Survived</span>
                        <span className="text-[10px] font-medium text-emerald-100 mt-0.5 block truncate">
                          {urgesSurvived} peak cycles survived
                        </span>
                      </div>
                    </div>

                    {/* Metric 3: Honesty Streak */}
                    <div className="relative overflow-hidden bg-white/[0.01] border border-white/5 p-1.5 sm:p-2 rounded-xl flex items-center space-x-2 transition-all duration-300 hover:bg-white/[0.03]">
                      <span className="absolute right-0 bottom-0 w-8 h-8 rounded-full bg-purple-500/5 blur-xs pointer-events-none" />
                      <div className="w-6 h-6 rounded-lg bg-purple-500/10 border border-purple-500/20 flex items-center justify-center text-purple-400 font-mono tracking-tight text-[10px] shrink-0 font-bold">
                        {honestyStreak}x
                      </div>
                      <div className="min-w-0 flex-1">
                        <span className="text-[7.5px] font-mono text-gray-400 uppercase tracking-widest block leading-none font-semibold">Honesty Streak</span>
                        <span className="text-[10px] font-medium text-purple-100 mt-0.5 block truncate">
                          {honestyStreak} verbal disclosures
                        </span>
                      </div>
                    </div>

                    {/* Metric 4: Recovery Consistency */}
                    <div className="relative overflow-hidden bg-white/[0.01] border border-white/5 p-1.5 sm:p-2 rounded-xl flex items-center space-x-2 transition-all duration-300 hover:bg-white/[0.03]">
                      <span className="absolute right-0 bottom-0 w-8 h-8 rounded-full bg-indigo-500/5 blur-xs pointer-events-none" />
                      <div className="w-6 h-6 rounded-lg bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400 font-mono tracking-tight text-[10px] shrink-0 font-bold">
                        {consistency}%
                      </div>
                      <div className="min-w-0 flex-1">
                        <span className="text-[7.5px] font-mono text-gray-400 uppercase tracking-widest block leading-none">Sanctuary Health</span>
                        <span className="text-[10px] font-medium text-indigo-100 mt-0.5 block truncate">
                          {consistency}% integrity scale
                        </span>
                      </div>
                    </div>

                  </div>

                  {/* WHATSAPP/DISCORD-LIKE CINEMATIC CHAT HEADER */}
                  <div className="flex items-center justify-between pb-3 shrink-0 border-b border-white/5 select-none animate-fadeIn">
                    <div className="flex items-center space-x-3 min-w-0">
                      {/* Sidebar toggle button (for Mobile) */}
                      <button 
                        onClick={() => setIsSidebarOpen(!isSidebarOpen)}
                        className="lg:hidden p-1.5 rounded-xl bg-white/5 border border-white/5 text-indigo-300 transition-all hover:bg-white/10 shrink-0"
                        title="View sitting rooms list"
                      >
                        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                          <line x1="3" x2="21" y1="6" y2="6"/>
                          <line x1="3" x2="21" y1="12" y2="12"/>
                          <line x1="3" x2="21" y1="18" y2="18"/>
                        </svg>
                      </button>

                      {/* Glowing Hearth Avatar */}
                      <div className="relative shrink-0">
                        <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-amber-500/25 to-indigo-600/20 border border-amber-500/20 flex items-center justify-center relative">
                          <span className="absolute inset-0 rounded-full bg-amber-400/10 animate-ping" />
                          <div className="w-2.5 h-2.5 rounded-full bg-gradient-to-tr from-amber-400 to-amber-500 shadow-[0_0_10px_rgba(245,158,11,0.5)] z-10" />
                        </div>
                      </div>

                      <div className="min-w-0">
                        <div className="flex items-center space-x-1.5">
                          <h2 className="text-xs sm:text-sm font-semibold tracking-tight text-white leading-none">
                            {chatThreads.find(t => t.id === activeThreadId)?.title || "Quiet Cabin Hearth"}
                          </h2>
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse shrink-0" title="Companion connection live" />
                        </div>
                        <p className="text-gray-400 text-[10px] sm:text-[11px] font-mono leading-none mt-1 truncate">
                          Brother • {ambientMode} Air
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center space-x-1.5 sm:space-x-2 shrink-0">
                      {/* Quiet Slit Reset Action */}
                      <button 
                        type="button"
                        onClick={() => setIsRelapseResetPlaying(true)}
                        className="p-1 px-2.5 bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 rounded-lg border border-rose-500/25 text-[9px] font-mono flex items-center space-x-1 uppercase transition-all duration-300 cursor-pointer shadow-md shadow-rose-950/10 shrink-0"
                        title="Acknowledge a relapse or slip-up with compassion"
                      >
                        <RotateCcw size={9} className="text-rose-400" />
                        <span className="hidden sm:inline">Log Slip Gently</span>
                        <span className="sm:hidden">Slip</span>
                      </button>

                      {/* Memory Drawer Search Toggle */}
                      <button 
                        type="button"
                        onClick={() => setIsChatSearchOpen(!isChatSearchOpen)}
                        className={`p-1.5 rounded-lg border transition-all duration-300 cursor-pointer ${
                          isChatSearchOpen 
                            ? "bg-indigo-600/25 border-indigo-500/40 text-indigo-300 shadow-sm" 
                            : "bg-white/5 hover:bg-white/10 text-gray-500 hover:text-gray-200 border-white/5"
                        }`}
                        title="Search conversation history"
                      >
                        <Search size={12} />
                      </button>

                      {/* Fullscreen Immersion Mode Toggle */}
                      <button 
                        type="button"
                        onClick={() => setIsChatImmersionMode(!isChatImmersionMode)}
                        className={`p-1.5 rounded-lg border transition-all duration-300 cursor-pointer ${
                          isChatImmersionMode 
                            ? "bg-amber-500/20 hover:bg-amber-500/25 text-amber-300 border-amber-500/30" 
                            : "bg-white/5 hover:bg-white/10 text-gray-300 border-white/5"
                        }`}
                        title="Toggle deep immersion focus mode"
                      >
                        {isChatImmersionMode ? <Sun size={12} /> : <Moon size={12} />}
                      </button>
                    </div>
                  </div>

                  {/* SLIDE-DOWN SEARCH & MEMORY ARCHIVAL TOOLS */}
                  {isChatSearchOpen && (
                    <div className="flex flex-col sm:flex-row gap-2 justify-between items-stretch sm:items-center bg-black/45 border border-indigo-500/15 p-2 rounded-xl shrink-0 my-1 font-mono text-[10px] relative z-20">
                      {/* Search textbox input */}
                      <div className="relative flex-1 max-w-xs">
                        <Search size={11} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-500" />
                        <input 
                          type="text" 
                          placeholder="search companion logs..."
                          value={chatSearchQuery}
                          onChange={(e) => setChatSearchQuery(e.target.value)}
                          className="w-full bg-[#050508] border border-white/5 rounded-lg pl-7 pr-10 py-1.5 text-[11px] text-slate-200 placeholder:text-gray-500 focus:outline-none focus:border-indigo-500/30 transition-all font-mono"
                        />
                        {chatSearchQuery && (
                          <button 
                            onClick={() => setChatSearchQuery("")}
                            className="absolute right-2 top-1/2 -translate-y-1/2 text-[9px] bg-white/5 hover:bg-white/10 px-1.5 py-0.5 rounded text-gray-400 hover:text-white font-mono"
                            type="button"
                          >
                            clear
                          </button>
                        )}
                      </div>

                      {/* Memory classifications */}
                      <div className="flex items-center space-x-1 overflow-x-auto no-scrollbar py-0.5 max-w-full">
                        {[
                          { key: null, label: "all entries" },
                          { key: "pinned", label: "saved records" },
                          { key: "short", label: "short-term context" },
                          { key: "medium", label: "behavior habits" },
                          { key: "long", label: "long-term anchors" },
                        ].map((btn) => (
                          <button
                            key={btn.label}
                            type="button"
                            onClick={() => setIsMemoryFilterActive(btn.key as any)}
                            className={`px-2.5 py-1 text-[8.5px] rounded-md border font-mono transition-all uppercase whitespace-nowrap cursor-pointer ${
                              isMemoryFilterActive === btn.key 
                                ? "bg-indigo-500/20 text-indigo-300 border-indigo-500/40" 
                                : "bg-white/[0.01] text-gray-500 border-white/5 hover:border-gray-700 hover:text-gray-300"
                            }`}
                          >
                            {btn.label}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Active messages list wrapper with perfect viewport calculations */}
                  <div className={`flex flex-col flex-1 min-h-0 justify-between relative overflow-hidden transition-all duration-300 ${
                    isChatImmersionMode 
                      ? "bg-transparent border-0 p-0 shadow-none" 
                      : "glass-panel p-4 rounded-2xl border-white/5"
                  }`}>

                    {/* Relapse / slip-up supportive animation screen */}
                    {isRelapseResetPlaying && (
                      <div className="absolute inset-x-0 inset-y-0 bg-[#06080d]/96 backdrop-blur-3xl z-50 flex flex-col items-center justify-center p-6 text-center animate-[fadeIn_0.5s_ease-out] rounded-2xl select-none">
                        <div className="max-w-md mx-auto space-y-6">
                          <div className="flex justify-center">
                            <div className="w-14 h-14 rounded-full bg-white/[0.02] border border-white/10 flex items-center justify-center text-sky-400">
                              <CloudRain className="w-6 h-6 animate-pulse" />
                            </div>
                          </div>
                          
                          <div className="space-y-2">
                            <h3 className="text-base font-semibold text-white tracking-tight">One difficult night does not erase your progress.</h3>
                            <p className="text-xs text-gray-400 font-light leading-relaxed">
                              Falling is not a verdict; it is just a moment. You are continuing a healing journey and you have more self-knowledge than before. We can start again quietly, side-by-side. No judgment and no aggressive counters.
                            </p>
                          </div>

                          <div className="space-y-1.5 py-2 px-3 font-mono text-[9px] text-gray-500 bg-white/[0.01] rounded-lg border border-white/5">
                            <p>Preserved Nights Survived: <span className="text-slate-200">{urgesSurvived} peak cycles</span></p>
                            <p>Current atmosphere Index: <span className="text-indigo-300">Soft protective mist clearing slowly</span></p>
                          </div>

                          <div className="flex justify-center pt-2">
                            <button
                              type="button"
                              onClick={() => {
                                // Reset stats with compassion
                                setRecoveryDays(1);
                                setConsistency(prev => Math.max(70, prev - 6));
                                setIsRelapseResetPlaying(false);
                                
                                // Dispatch comforting assistant message to timeline
                                const customId = Date.now() + "_reset_sys";
                                const systemMsg: ChatMessage = {
                                  id: customId,
                                  role: "assistant",
                                  text: "hey, look at me. it is okay to have a setback. the fact that you stepped in here to log it honestly holds more weight than any perfect score. you are still here, okay? let us stay quiet and take this hour as it comes.",
                                  timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                                  isStreamingComplete: true
                                };
                                setChatHistory(prev => [...prev, systemMsg]);
                              }}
                              className="px-6 py-2.5 bg-indigo-500/20 hover:bg-slate-100 hover:text-black hover:border-white text-indigo-300 border border-indigo-500/30 rounded-xl text-xs font-semibold tracking-wide transition-all active:scale-95 cursor-pointer shadow-lg"
                            >
                              Start Again Gently
                            </button>
                          </div>
                        </div>
                      </div>
                    )}
                    
                    {/* Message list - ONLY vertical scrolling scrollbox */}
                    <div 
                      ref={chatScrollContainerRef}
                      onScroll={handleChatScroll}
                      className="flex-1 overflow-y-auto pr-1 space-y-4 select-text scroll-smooth -webkit-overflow-scrolling-touch no-scrollbar"
                      id="message_scroll_viewer"
                    >
                      {chatHistory.filter((m) => {
                        const tid = m.threadId || "default_thread";
                        if (tid !== activeThreadId) return false;

                        if (chatSearchQuery.trim() !== "") {
                          return m.text.toLowerCase().includes(chatSearchQuery.toLowerCase());
                        }
                        if (isMemoryFilterActive === "pinned") {
                          return m.isPinned;
                        }
                        if (isMemoryFilterActive) {
                          return m.isPinned && m.memoryType === isMemoryFilterActive;
                        }
                        return true;
                      }).length === 0 ? (
                        <div className="flex flex-col items-center justify-center h-full text-center p-6 space-y-2">
                          <Calendar size={24} className="text-gray-600 animate-pulse" />
                          <p className="text-gray-400 text-xs font-light">no archived conversation matches your filtering</p>
                          <button 
                            onClick={() => { setChatSearchQuery(""); setIsMemoryFilterActive(null); }}
                            className="text-xs text-indigo-400 underline hover:text-indigo-300 cursor-pointer"
                          >
                            restore whole timeline
                          </button>
                        </div>
                      ) : (
                        chatHistory.filter((m) => {
                          const tid = m.threadId || "default_thread";
                          if (tid !== activeThreadId) return false;

                          if (chatSearchQuery.trim() !== "") {
                            return m.text.toLowerCase().includes(chatSearchQuery.toLowerCase());
                          }
                          if (isMemoryFilterActive === "pinned") {
                            return m.isPinned;
                          }
                          if (isMemoryFilterActive) {
                            return m.isPinned && m.memoryType === isMemoryFilterActive;
                          }
                          return true;
                        }).map((m, index) => {
                          const showSeparator = index === 0;

                          return (
                            <div key={m.id} className="space-y-2 select-text">
                              {showSeparator && (
                                <div className="flex items-center justify-center py-2 select-none">
                                  <span className="bg-white/[0.02] border border-white/5 px-4 py-1.5 rounded-full text-[8.5px] font-mono text-gray-400 tracking-wider flex items-center space-x-1.5 uppercase">
                                    <Calendar size={10} className="text-indigo-400" />
                                    <span>HEARTH TIMELINE OVERVIEW ACTIVE • {ambientMode} Air</span>
                                  </span>
                                </div>
                              )}

                              {/* Pinned Marker Frame Header */}
                              {m.isPinned && (
                                <div className="flex items-center space-x-2 pl-3 select-none">
                                  <span className="text-[9px] bg-gradient-to-r from-indigo-500/10 to-purple-500/5 text-indigo-300 border border-indigo-500/20 rounded-md px-2.5 py-0.5 font-mono tracking-wide flex items-center">
                                    <Pin size={8} className="mr-1 fill-indigo-400 animate-pulse text-indigo-400" />
                                    {m.memoryType === "long" ? "🌌 COGNITIVE ANCHOR MEMORY" : m.memoryType === "medium" ? "📈 REPEATED BEHAVIOR PATTERN" : "💡 CONTEXT METADATA"}
                                  </span>
                                </div>
                              )}

                              <div 
                                className={`flex flex-col space-y-1.5 max-w-[85%] relative group ${
                                  m.role === "user" ? "ml-auto text-right items-end" : "mr-auto text-left items-start animate-[fadeIn_0.5s_ease]"
                                } ${m.isPinned ? "border-l-2 border-indigo-500/25 bg-indigo-500/[0.01] rounded-r-xl p-2.5 transition-all" : ""}`}
                              >
                                {/* Speaker timestamp tags */}
                                <div className="flex items-center space-x-2 select-none">
                                  <span className="text-[9px] font-mono text-gray-500 tracking-wider">
                                    {m.role === "user" ? username || "you" : "Brother"} • {m.timestamp}
                                  </span>

                                  {/* Pin Dropdown Action Menu */}
                                  <div className="relative inline-block">
                                    <button 
                                      onClick={() => setActivePinMsgId(activePinMsgId === m.id ? null : m.id)}
                                      className={`p-1 rounded-lg opacity-45 hover:opacity-100 transition-all cursor-pointer ${m.isPinned ? 'text-indigo-400 opacity-100 font-bold' : 'text-gray-500 hover:text-gray-200'}`}
                                      title="Store this emotional memory point"
                                      type="button"
                                    >
                                      <Pin size={10} className={`${m.isPinned ? "fill-indigo-400" : ""}`} />
                                    </button>

                                    {/* Select Menu list popover positioning */}
                                    {activePinMsgId === m.id && (
                                      <div className="absolute right-0 bottom-6 bg-[#09090f] text-[#e0e3eb] text-xs rounded-xl border border-white/10 p-2 z-50 shadow-2xl w-48 text-left space-y-1 animate-fadeIn">
                                        <span className="block text-[8px] font-mono text-gray-500 px-1 uppercase tracking-wider pb-1 border-b border-white/5 mb-1">
                                          Memory layer scale:
                                        </span>
                                        {m.isPinned ? (
                                          <button 
                                            onClick={() => togglePinMessage(m.id)}
                                            className="w-full text-left px-2 py-1.5 rounded-lg hover:bg-rose-500/10 text-rose-400 font-mono text-[9px] uppercase cursor-pointer"
                                            type="button"
                                          >
                                            ❌ Unpin Memory Log
                                          </button>
                                        ) : (
                                          <>
                                            <button 
                                              onClick={() => togglePinMessage(m.id, "short")}
                                              className="w-full text-left px-2 py-1 rounded hover:bg-white/5 flex flex-col font-mono text-[9px] cursor-pointer"
                                              type="button"
                                            >
                                              <span className="text-white">💡 Short-Term Context</span>
                                              <span className="text-gray-500 text-[8px]">Temporary stress, mood today</span>
                                            </button>
                                            <button 
                                              onClick={() => togglePinMessage(m.id, "medium")}
                                              className="w-full text-left px-2 py-1 rounded hover:bg-white/5 flex flex-col font-mono text-[9px] cursor-pointer"
                                              type="button"
                                            >
                                              <span className="text-white">📈 Medium-Term Pattern</span>
                                              <span className="text-gray-500 text-[8px]">Underlying trigger habits</span>
                                            </button>
                                            <button 
                                              onClick={() => togglePinMessage(m.id, "long")}
                                              className="w-full text-[#e0e3eb] text-left px-2 py-1 rounded hover:bg-white/5 flex flex-col font-mono text-[9px] cursor-pointer"
                                              type="button"
                                            >
                                              <span className="text-white">🌌 Long-Term Anchor</span>
                                              <span className="text-gray-500 text-[8px]">Breakthroughs, deep fears</span>
                                            </button>
                                          </>
                                        )}
                                      </div>
                                    )}
                                  </div>
                                </div>

                                {/* Speech bubble custom designs (WhatsApp + Discord premium fusion) */}
                                {m.role === "user" ? (
                                  <div className="bg-gradient-to-br from-indigo-650/20 via-indigo-700/15 to-purple-800/15 border border-indigo-500/20 hover:border-indigo-400/35 text-slate-100 px-4.5 py-2.5 rounded-2xl rounded-tr-none shadow-[0_4px_16px_rgba(99,102,241,0.04)] hover:shadow-[0_0_24px_rgba(99,102,241,0.12)] transition-all duration-300 text-xs sm:text-[13px] leading-relaxed text-left max-w-full select-text selection:bg-indigo-500/30">
                                    {m.text}
                                  </div>
                                ) : (
                                  <div className="bg-[#10121a]/85 border border-white/5 hover:border-indigo-500/10 text-slate-100 px-4.5 py-3 rounded-2xl rounded-tl-none shadow-[0_4px_20px_rgba(0,0,0,0.15)] hover:shadow-[0_0_24px_rgba(255,255,255,0.02)] transition-all duration-300 text-xs sm:text-[13.5px] leading-relaxed whitespace-pre-wrap pl-4 pr-5 selection:bg-indigo-500/30 font-light tracking-wide">
                                    {m.text}
                                  </div>
                                )}
                              </div>
                            </div>
                          );
                        })
                      )}

                      {/* Animated custom visual typing indicators */}
                      {isAiTyping && (
                        <div className="flex flex-col space-y-1.5 items-start mr-auto select-none mt-2">
                          <span className="text-[9px] font-mono text-gray-500 tracking-wider">Brother is writing...</span>
                          <div className="flex items-center space-x-1.5 p-3 bg-white/[0.01] border border-white/5 rounded-2xl rounded-tl-none">
                            <span className="w-1.5 h-1.5 rounded-full bg-indigo-400 animate-bounce [animation-delay:-0.3s]" />
                            <span className="w-1.5 h-1.5 rounded-full bg-purple-400 animate-bounce [animation-delay:-0.15s]" />
                            <span className="w-1.5 h-1.5 rounded-full bg-indigo-300 animate-bounce" />
                          </div>
                        </div>
                      )}
                      
                      <div ref={chatBottomRef} />
                    </div>

                    {/* Jump To Bottom Floating Button */}
                    {showJumpToBottom && (
                      <button
                        type="button"
                        onClick={jumpToBottom}
                        className="absolute bottom-24 right-6 bg-[#0a0a14]/90 border border-indigo-500/30 text-indigo-300 hover:text-white p-2.5 rounded-full shadow-[0_0_15px_rgba(99,102,241,0.2)] flex items-center justify-center cursor-pointer transition-all hover:scale-105 active:scale-95 animate-bounce z-40"
                        title="Jump to newest messages"
                      >
                        <ArrowDown size={14} />
                      </button>
                    )}

                    {/* Submission typing system */}
                    <form id="chat_form_companion" onSubmit={handleChatSend} className="shrink-0 pt-2 border-t border-white/5 bg-transparent select-none">
                      
                      {/* Quick grounding helper nodes */}
                      <div className="flex items-center space-x-1.5 py-1.5 sm:py-2 overflow-x-auto select-none no-scrollbar opacity-85">
                        {[
                          "it's 2 AM and my mind is racing...",
                          "i'm feeling a really strong urge.",
                          "i managed to survive the night.",
                          "need to ground myself right now."
                        ].map((term) => (
                          <button
                            key={term}
                            type="button"
                            onClick={() => setChatInput(term)}
                            className="text-[8.5px] font-mono uppercase tracking-wider bg-white/[0.02] hover:bg-indigo-500/10 hover:text-indigo-200 border border-white/5 hover:border-indigo-500/20 text-gray-400 rounded-full px-3 py-1 whitespace-nowrap transition-all duration-300 cursor-pointer"
                          >
                            {term}
                          </button>
                        ))}
                      </div>

                      {/* Unified stable input dock */}
                      <div className="flex items-center space-x-2 mt-1 w-full relative">
                        {/* Compact emotional status icon */}
                        <div className="hidden sm:flex items-center justify-center w-10 h-10 rounded-xl bg-white/[0.02] border border-white/5 text-indigo-400/80 hover:text-indigo-300 shrink-0 transition-colors">
                          <Heart size={14} className="animate-pulse" />
                        </div>

                        {/* Input Core Area */}
                        <div className="relative flex-1 flex items-center">
                          <input
                            type="text"
                            value={chatInput}
                            onChange={(e) => setChatInput(e.target.value)}
                            placeholder="What's heavy tonight? Stay here for a minute..."
                            className="w-full py-3.5 pl-4 pr-12 rounded-2xl bg-[#030305]/65 hover:bg-black/60 text-[#e0e3eb] text-xs sm:text-sm placeholder-gray-500 focus:outline-none focus:border-indigo-500/30 focus:ring-1 focus:ring-indigo-500/20 border border-white/5 transition-all duration-300 shadow-[0_4px_24px_rgba(0,0,0,0.3)] focus:shadow-[0_0_25px_rgba(99,102,241,0.08)] font-sans"
                          />
                          
                          {/* Mic Voice Sanctuary Placeholder Option */}
                          <button
                            type="button"
                            className="absolute right-3 p-1.5 rounded-lg text-gray-500 hover:text-indigo-300 transition-all cursor-pointer"
                            title="Activate Voice Grounding helper"
                            onClick={() => {
                              const customNotification = {
                                id: Date.now().toString(),
                                text: "Voice Sanctuary activated. Let's practice slow, deep breathing as you speak.",
                                time: "Now"
                              };
                              setNotifications(prev => [customNotification, ...prev]);
                            }}
                          >
                            <Mic size={14} />
                          </button>
                        </div>

                        {/* Elegant floating styled Send action button */}
                        <button
                          type="submit"
                          id="chat_send_button"
                          className="p-3.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-2xl transition-all duration-300 hover:scale-[1.03] active:scale-95 flex items-center justify-center cursor-pointer shadow-lg shadow-indigo-600/25 shrink-0"
                          title="Send message"
                        >
                          <Send size={14} />
                        </button>
                      </div>
                    </form>

                  </div>

                </div>

              </div>
            )}

            {/* 3. EMOTIONAL JOURNAL SHEETS VIEW */}
            {activeTab === "journal" && (
              <div className="flex-1 overflow-y-auto overscroll-contain no-scrollbar pr-1 pb-24 space-y-6">
                
                {/* Header context info */}
                <div className="space-y-1">
                  <h2 className="text-2xl font-semibold tracking-tight text-white">Truth Log worksheet</h2>
                  <p className="text-gray-400 text-xs">
                    vent what you've suppressed from the screens, work stress, parents, or cold habits. when you compile several pages, the summarizer details poetic climate reflections.
                  </p>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
                  
                  {/* Left hand creation pad */}
                  <div className="lg:col-span-7 glass-panel p-6 rounded-3xl border-white/5 space-y-4">
                    <h3 className="text-sm font-mono text-indigo-300 uppercase tracking-widest">New honest expression</h3>
                    
                    <form onSubmit={handleSaveJournal} className="space-y-4">
                      
                      {/* Mood selector tag list */}
                      <div className="space-y-2">
                        <label className="text-xs font-mono text-gray-400 uppercase tracking-wider block">Mood indicator</label>
                        <div className="grid grid-cols-3 gap-2">
                          {[
                            { id: "heavy", label: "Very Heavy" },
                            { id: "numb", label: "Numb" },
                            { id: "anxious", label: "Anxious" },
                            { id: "lonely", label: "Lonely" },
                            { id: "overthinking", label: "Overthinking" },
                            { id: "peaceful", label: "Peaceful" },
                          ].map((moodSpec) => (
                            <button
                              key={moodSpec.id}
                              type="button"
                              onClick={() => setSelectedMood(moodSpec.id as JournalEntry["mood"])}
                              className={`py-2 px-1 text-center text-xs rounded-xl border transition-all cursor-pointer ${
                                selectedMood === moodSpec.id
                                  ? "bg-indigo-500/20 text-indigo-300 border-indigo-500/40"
                                  : "bg-white/[0.01] border-white/5 text-gray-400 hover:border-white/10"
                              }`}
                            >
                              {moodSpec.label}
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* Text typing pad input details */}
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <label className="text-xs font-mono text-gray-400 uppercase tracking-wider block">Write it down</label>
                          
                          {/* Recording simulation helpers */}
                          <div className="flex items-center space-x-2">
                            {isVoiceRecording ? (
                              <button
                                type="button"
                                onClick={stopRecordingSimAndFill}
                                className="flex items-center space-x-1 px-3 py-1 bg-rose-500/20 border border-rose-500/30 text-rose-300 rounded-full text-[10px] font-mono animate-pulse"
                              >
                                <MicOff size={10} />
                                <span>Stop ({voiceTimer}s)</span>
                              </button>
                            ) : (
                              <button
                                type="button"
                                onClick={startRecordingSim}
                                className="flex items-center space-x-1 px-3 py-1 bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white rounded-full text-[10px] font-mono transition-all"
                              >
                                <Mic size={10} />
                                <span>Dictate Speak</span>
                              </button>
                            )}
                          </div>
                        </div>

                        {/* Real input box */}
                        <textarea
                          placeholder="pour your heavy raw truth. no formatting, no worries. spell horribly, curse, shout. we are safely private."
                          rows={6}
                          value={journalContent}
                          onChange={(e) => setJournalContent(e.target.value)}
                          className="w-full p-4 rounded-2xl glass-input text-sm leading-relaxed"
                          required
                        />
                      </div>

                      {/* Tag inputs splitter */}
                      <div className="space-y-1.5">
                        <label className="text-xs font-mono text-gray-400 uppercase tracking-wider block">Custom search tags (split with comma)</label>
                        <input
                          type="text"
                          placeholder="e.g. urge, work, family, shame"
                          value={journalTagsInput}
                          onChange={(e) => setJournalTagsInput(e.target.value)}
                          className="w-full p-3.5 rounded-xl text-xs glass-input"
                        />
                      </div>

                      <button
                        type="submit"
                        className="w-full py-3.5 bg-white text-black hover:bg-neutral-200 text-xs font-semibold rounded-xl text-center uppercase tracking-widest transition-all cursor-pointer"
                        id="save_journal_button"
                      >
                        Quietly file entry
                      </button>

                    </form>

                  </div>

                  {/* Right hand compiled entries lists */}
                  <div className="lg:col-span-5 space-y-4">
                    <div className="flex items-center justify-between border-b border-white/5 pb-2">
                      <h4 className="text-xs font-mono text-gray-400 uppercase tracking-wider">Historical Logs ({journals.length})</h4>
                      {journals.length > 0 && (
                        <button
                          onClick={handleSummarizeJournals}
                          id="btn_climate_report"
                          disabled={isSummarizingJournal}
                          className="text-xs text-indigo-400 hover:text-indigo-300 flex items-center space-x-1 cursor-pointer disabled:opacity-50"
                        >
                          <Activity size={12} className="animate-pulse" />
                          <span>{isSummarizingJournal ? "Drawing Report..." : "Weather Report"}</span>
                        </button>
                      )}
                    </div>

                    {/* Report text print panel block */}
                    {journalSummary && (
                      <div className="p-4 rounded-2xl bg-gradient-to-tr from-indigo-500/[0.04] to-purple-500/[0.02] border border-indigo-500/25 space-y-2 select-text animate-fadeIn">
                        <div className="flex items-center space-x-1 text-indigo-400">
                          <Sparkles size={11} className="text-amber-400 animate-spin" />
                          <span className="text-[9px] font-mono uppercase tracking-wider font-semibold">Poetic Weather Reflection</span>
                        </div>
                        <p className="text-xs text-indigo-200 leading-relaxed font-serif italic">
                          "{journalSummary}"
                        </p>
                      </div>
                    )}

                    {/* Journals mapped stack list */}
                    {journals.length === 0 ? (
                      <div className="p-8 text-center rounded-2xl bg-white/[0.01] border border-white/5 text-xs text-gray-500 block font-light leading-relaxed">
                        No private sheets logged yet. Fill your first honest entry in the pad space to begin.
                      </div>
                    ) : (
                      <div className="space-y-3 max-h-[440px] overflow-y-auto pr-1">
                        {journals.map((j) => (
                          <div key={j.id} className="p-4 rounded-xl bg-white/[0.01] hover:bg-white/[0.02] border border-white/5 flex flex-col justify-between space-y-3 relative group transition-all select-text">
                            
                            {/* Metadata header line */}
                            <div className="flex items-center justify-between">
                              <span className="text-[10px] font-mono text-purple-400 bg-purple-500/10 px-2 py-0.5 rounded-md capitalize">
                                {j.mood} thoughts
                              </span>
                              <span className="text-[9px] font-mono text-gray-500">{j.date}</span>
                            </div>

                            {/* Content written */}
                            <p className="text-xs text-gray-300 leading-relaxed font-light break-words select-text">
                              {j.content}
                            </p>

                            {/* Tags row */}
                            <div className="flex flex-wrap gap-1 pt-1.5 border-t border-white/[0.03]">
                              {j.tags.map((tg) => (
                                <span key={tg} className="text-[9px] font-mono text-indigo-400 hover:text-indigo-300 transition-colors mr-1.5">
                                  #{tg}
                                </span>
                              ))}
                            </div>

                            {/* Delete Button */}
                            <button
                              onClick={() => handleDeleteJournal(j.id)}
                              className="absolute top-2 right-2 text-gray-600 hover:text-rose-400 opacity-0 group-hover:opacity-100 transition-opacity p-1.5"
                              title="Delete Worksheet entry"
                            >
                              <Trash2 size={13} />
                            </button>

                          </div>
                        ))}
                      </div>
                    )}

                  </div>

                </div>

              </div>
            )}

            {/* 4. THE INTEGRATED SHIELD SOMATIC CONTAINMENT PAGE */}
            {activeTab === "shield" && (
              <div className="flex-1 overflow-y-auto overscroll-contain no-scrollbar pr-1 pb-24 space-y-6 animate-[fadeIn_0.5s_ease-out]">
                
                {/* Header panel block */}
                <div className="space-y-1">
                  <h2 className="text-2xl font-semibold tracking-tight text-white">Consolidated Somatic Containment Shield</h2>
                  <p className="text-gray-400 text-xs">
                    We do not fight intense urges with rules. We ground your body's nervous system, slow heart rates, and ride the peak until the tide flows out.
                  </p>
                </div>

                {/* Major alert layout activator screen panel */}
                <div className="p-8 rounded-3xl border border-rose-500/20 bg-gradient-to-tr from-[#13080c] via-[#050510] to-[#04040a] text-center space-y-6 relative overflow-hidden shadow-2xl">
                  {/* Glowing warning accents */}
                  <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-rose-500/10 rounded-full blur-[100px] pointer-events-none" />
                  
                  <div className="space-y-2 relative z-10">
                    <span className="text-[10px] font-mono tracking-[0.4em] text-rose-500 uppercase font-extrabold block animate-pulse">
                      CRITICAL CONTAINMENT TRIGGER
                    </span>
                    <h3 className="text-3xl font-extralight tracking-tight text-white">Struggling with late-night impulses or dark thoughts?</h3>
                    <p className="text-gray-400 text-xs max-w-md mx-auto leading-relaxed">
                      Don't fight yourself. Lock the sheets. Open this fullscreen locking safety circle. We will do 5 slow minutes together, and wait till your blood pressure settles.
                    </p>
                  </div>

                  <button
                    onClick={() => {
                      setIsEmergencyActive(true);
                      const nextCount = urgesSurvived + 1;
                      handleMuteAction(nextCount);
                    }}
                    id="shield_btn_large_close"
                    className="px-10 py-5 bg-rose-500/10 hover:bg-rose-500/25 text-rose-300 font-bold uppercase tracking-widest border border-rose-500/35 rounded-full text-xs transition-all duration-300 transform active:scale-95 shadow-lg shadow-rose-950/20 cursor-pointer animate-pulse"
                  >
                    🚀 ACTIVATE "I'M CLOSE" SHIELD
                  </button>

                  <div className="text-[9px] text-gray-500 font-mono select-none">
                    CLICKING LAUNCHES FULLSCREEN LOCKING GROUNDING LAYOUTS IMMEDIATELY
                  </div>
                </div>

                {/* Sub bilateral containment grids */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  
                  {/* Card 1: Cold shower Stopwatch */}
                  <div className="glass-panel p-5 rounded-2xl border-white/5 bg-gradient-to-b from-blue-500/[0.02] to-transparent flex flex-col justify-between space-y-6">
                    <div className="space-y-2">
                      <span className="text-xs bg-blue-500/10 text-blue-400 px-2.5 py-1 rounded-full border border-blue-500/20 font-mono">
                        Cold Shower Grid
                      </span>
                      <h4 className="text-[#ededf3] font-medium text-md mt-2">Ice water thermal trigger</h4>
                      <p className="text-gray-400 text-xs leading-relaxed font-light">
                        Ice water triggers a major mammalian dive reflex. It forces your neural circuitry to immediately reset, halting dopamine craving states in 180 seconds.
                      </p>
                    </div>

                    <div className="space-y-3 text-center">
                      <span className="text-4xl font-mono tracking-widest text-slate-100 font-bold block">
                        {Math.floor(coldTimer / 60)}:{(coldTimer % 60) < 10 ? "0" : ""}{coldTimer % 60}
                      </span>
                      
                      <div className="flex space-x-2">
                        <button
                          onClick={() => setIsColdActive(!isColdActive)}
                          id="survival_btn_shower_start"
                          className="flex-1 py-2 rounded-xl text-xs font-semibold uppercase tracking-wider transition-all cursor-pointer bg-white text-black hover:bg-neutral-200"
                        >
                          {isColdActive ? "Pause" : "Initiate 3 Min"}
                        </button>
                        <button
                          onClick={_resetShowerSettings}
                          className="px-3 rounded-xl bg-white/5 text-gray-400 hover:text-white transition-colors cursor-pointer"
                        >
                          <RotateCcw size={13} />
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Card 2: Grounding Walk Metronome */}
                  <div className="glass-panel p-5 rounded-2xl border-white/5 bg-gradient-to-b from-amber-500/[0.02] to-transparent flex flex-col justify-between space-y-6">
                    <div className="space-y-2">
                      <span className="text-xs bg-amber-500/10 text-amber-300 px-2.5 py-1 rounded-full border border-amber-500/20 font-mono font-semibold">
                        Bilateral Metronome
                      </span>
                      <h4 className="text-[#ededf3] font-medium text-md mt-2">Bilateral pacing walk</h4>
                      <p className="text-gray-400 text-xs leading-relaxed font-light">
                        Force your gaze into standard horizontal movement. Slower, paced steps trigger high-level cognitive soothing mechanisms, decreasing autonomic stress responses.
                      </p>
                    </div>

                    <div className="space-y-3">
                      <div className="h-10 grid grid-cols-2 gap-4 items-center justify-center text-center">
                        <span className={`p-1.5 rounded-xl text-xs font-mono transition-all border ${
                          isWalkActive && walkBeat === "left" 
                            ? "bg-purple-500/20 text-purple-300 border-purple-500/40" 
                            : "bg-white/[0.01] border-white/5 text-gray-500"
                        }`}>
                          LEFT STEP
                        </span>
                        <span className={`p-1.5 rounded-xl text-xs font-mono transition-all border ${
                          isWalkActive && walkBeat === "right" 
                            ? "bg-purple-500/20 text-purple-300 border-purple-500/40" 
                            : "bg-white/[0.01] border-white/5 text-gray-500"
                        }`}>
                          RIGHT STEP
                        </span>
                      </div>

                      <button
                        onClick={() => setIsWalkActive(!isWalkActive)}
                        id="survival_btn_walk_toggle"
                        className="w-full py-2 bg-white/5 text-slate-100 hover:bg-white/10 text-xs font-mono rounded-xl transition-all border border-white/10 cursor-pointer"
                      >
                        {isWalkActive ? "HALT METRONOME" : "ACTIVATE PULSES"}
                      </button>
                    </div>
                  </div>

                </div>

                {/* Grounding tips guidance */}
                <div className="p-6 rounded-2xl bg-white/[0.01] border border-[#ff0055]/5 text-xs text-gray-400 leading-relaxed space-y-3">
                  <h4 className="text-rose-400 font-semibold text-sm">Remember this, brother:</h4>
                  <p>
                    1. **urges are not static requirements.** they behave precisely like waves on a shoreline. they rise, foam, peak, and slide back down. they usually last only 20-30 minutes if you do not actively keep feeding them with overthought feeds.
                  </p>
                  <p>
                    2. **isolation is the true fuel.** do not lock yourself away in your dark room wrestling. sit near the hearth, look around, grab a glass of ice water. we are stayed awake with you.
                  </p>
                </div>

              </div>
            )}

            {/* 5. JOURNEY MAP VIEW */}
            {activeTab === "journey" && (
              <div className="flex-1 overflow-y-auto overscroll-contain no-scrollbar pr-1 pb-24 space-y-6">
                
                {/* Header descriptor */}
                <div className="space-y-1">
                  <h2 className="text-2xl font-semibold tracking-tight text-white">Visual healing simulation</h2>
                  <p className="text-gray-400 text-sm">
                    No toxic streaks, pressure scales, or scoreboards. Just a visual metaphor representing your inner weather conditions as you choose honesty over suppression.
                  </p>
                </div>

                {/* Atmospheric representation growth rendering */}
                <div className="glass-panel p-6 rounded-3xl border-white/5 relative overflow-hidden flex flex-col items-center justify-center min-h-[300px] text-center space-y-4">
                  
                  {/* Dynamic Sky gradient based on Journals saved */}
                  <div className={`absolute inset-0 z-0 transition-opacity duration-1000 bg-gradient-to-b ${
                    honestyCount <= 2 
                      ? "from-slate-900 via-indigo-950/40 to-[#030303]" 
                      : honestyCount <= 5
                      ? "from-indigo-900/40 via-purple-900/20 to-[#030303]"
                      : "from-amber-900/20 via-sky-900/30 to-[#030303]"
                  }`} />

                  {/* Simulated fog elements dynamically faded by Honesty counts */}
                  <div 
                    className="absolute inset-0 pointer-events-none mix-blend-screen overflow-hidden transition-opacity duration-[2000ms] z-1"
                    style={{ opacity: Math.max(0.1, 1 - (honestyCount * 0.15)) }}
                  >
                    <div className="absolute top-1/4 w-[200vw] h-[150vh] bg-[radial-gradient(ellipse_at_center,_rgba(255,255,255,0.06),_transparent_70%)] animate-fog-left" />
                    <div className="absolute top-0 w-[200vw] h-[150vh] bg-[radial-gradient(ellipse_at_center,_rgba(255,255,255,0.04),_transparent_60%)] animate-fog-right" />
                  </div>

                  {/* Sprouted leaf foliage graphic node representing honesty logs */}
                  <div className="relative z-10 w-24 h-24 mb-4 flex items-end justify-center">
                    
                    {/* Level 0-2 (Sprout / Foggy) */}
                    {honestyCount <= 2 && (
                      <svg className="w-16 h-16 text-indigo-400 animate-pulse" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                        <path d="M12 22V10M12 10a4 4 0 0 0-4-4H4M12 10a4 4 0 0 1 4-4h4" strokeLinecap="round" />
                      </svg>
                    )}

                    {/* Level 3-5 (Small Shrub / Mild fog) */}
                    {honestyCount > 2 && honestyCount <= 5 && (
                      <svg className="w-20 h-20 text-emerald-400 animate-pulse" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                        <path d="M12 22V6M12 14a5 5 0 0 0-5-5H3M12 10a5 5 0 0 1 5-5h5M12 18a4 4 0 0 0-4-4H5M12 15a4 4 0 0 1 4-4h3" strokeLinecap="round" />
                      </svg>
                    )}

                    {/* Level 6+ (Tall beautiful tree / Sunlight clear sky) */}
                    {honestyCount > 5 && (
                      <svg className="w-24 h-24 text-green-400 animate-pulse" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                        <path d="M12 22V2M12 12a6 6 0 0 0-6-6H2M12 8a6 6 0 0 1 6-6h4M12 16a5 5 0 0 0-5-5H3M12 14a5 5 0 0 1 5-5h4" strokeLinecap="round" />
                      </svg>
                    )}

                  </div>

                  {/* Descriptive commentary mapping */}
                  <div className="relative z-10 space-y-1 max-w-sm">
                    <span className="text-[10px] font-mono tracking-widest text-[#a5b4fc] uppercase block">
                      {honestyCount <= 2 ? "HEAVY OVERCAST SCENERY" : honestyCount <= 5 ? "FOG QUIETLY DISPERSING" : "WARM MORNING TWILIGHT CLEARING"}
                    </span>
                    <h4 className="text-white text-md font-medium">
                      {honestyCount <= 2 ? "The fog sits thick tonight." : honestyCount <= 5 ? "Mild sunlight is showing through." : "A clear, quiet sky has emerged."}
                    </h4>
                    <p className="text-gray-400 text-xs font-light leading-relaxed">
                      {honestyCount <= 2 
                        ? "You are just getting started. Write what hurts inside your journal. Every paragraph of transparency pushes a layer of density back."
                        : honestyCount <= 5 
                        ? "You are choosing to confront instead of escaping. The foliage is growing. Keep bringing truth into this light."
                        : "The heavy clouds have broken. Look at what you've survived over these difficult nights—you did that. Be proud."}
                    </p>
                  </div>

                </div>

                {/* Sub-Bento insights representing therapeutic analytics */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  
                  {/* Bento 1: Honest history checkins */}
                  <div className="glass-panel p-5 rounded-2xl border-white/5 space-y-3">
                    <div className="flex items-center space-x-2 text-indigo-400">
                      <BookOpen size={16} />
                      <span className="text-xs font-mono tracking-wider uppercase">Honesty check-ins</span>
                    </div>
                    <div>
                      <span className="text-3xl font-mono text-white font-bold">{honestyCount}</span>
                      <p className="text-gray-400 text-xs mt-1">
                        Difficult issues spoken directly into silent logs instead of taking quick scrolls.
                      </p>
                    </div>
                  </div>

                  {/* Bento 2: Survived Nights */}
                  <div className="glass-panel p-5 rounded-2xl border-white/5 space-y-3">
                    <div className="flex items-center space-x-2 text-emerald-400">
                      <Shield size={16} />
                      <span className="text-xs font-mono tracking-wider uppercase">Nights Survived</span>
                    </div>
                    <div>
                      <span className="text-3xl font-mono text-white font-bold">{urgesSurvived}</span>
                      <p className="text-gray-400 text-xs mt-1">
                        Moments when stress or triggers screams were felt to the peak and survived.
                      </p>
                    </div>
                  </div>

                </div>

                {/* Pattern Insights section */}
                <div className="p-6 rounded-2xl bg-white/[0.01] border border-white/5 space-y-4">
                  <span className="text-[10px] font-mono text-gray-400 uppercase tracking-widest block">Emotional Pattern Insights</span>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    
                    <div className="space-y-1 text-xs">
                      <span className="text-purple-300 font-semibold block">Peak vulnerability hour: 11PM–1AM</span>
                      <p className="text-gray-400 font-light leading-relaxed">
                        Your logs indicate overthinking surges right after screen lights go down. Try starting exercises early.
                      </p>
                    </div>

                    <div className="space-y-1 text-xs">
                      <span className="text-sky-300 font-semibold block">Trigger response: Isolation</span>
                      <p className="text-gray-400 font-light leading-relaxed">
                        You tend to search for quick distractions after stressful, silent school or work days. Transparency dilutes search triggers.
                      </p>
                    </div>

                    <div className="space-y-1 text-xs">
                      <span className="text-amber-300 font-semibold block">Clarity rate is climbing</span>
                      <p className="text-gray-400 font-light leading-relaxed">
                        By logging what hurts, your weather index has cleared by approximately 35% over the past logs. Keep moving forward.
                      </p>
                    </div>

                  </div>
                </div>

              </div>
            )}

            {/* 6. SETTINGS TAB VIEW */}
            {activeTab === "settings" && (
              <div className="flex-1 overflow-y-auto overscroll-contain no-scrollbar pr-1 pb-24 space-y-6">
                
                {/* Header descriptor */}
                <div className="space-y-1">
                  <h2 className="text-2xl font-semibold tracking-tight text-white">General customizations</h2>
                  <p className="text-gray-400 text-sm">
                    Configure your name, toggle ambient modes, or test protective reminders inside this space.
                  </p>
                </div>

                {/* Custom list details */}
                <div className="glass-panel rounded-2xl border-white/5 p-5 space-y-6">
                  
                  {/* Name field customization */}
                  <div className="space-y-2">
                    <label className="text-xs font-mono text-gray-400 uppercase tracking-wider block">Your Name</label>
                    <input
                      type="text"
                      value={username}
                      onChange={(e) => handleUsernameChange(e.target.value)}
                      placeholder="e.g. brother, alex"
                      className="w-full max-w-md p-3 rounded-xl glass-input text-sm"
                    />
                    <p className="text-gray-500 text-[11px]">
                      This resets his greeting configurations to personalized settings.
                    </p>
                  </div>

                  {/* Themes selectors */}
                  <div className="space-y-2">
                    <label className="text-xs font-mono text-gray-400 uppercase tracking-wider block">Theme preference</label>
                    <div className="flex space-x-3">
                      <button
                        onClick={() => handleThemeChange("dark")}
                        className={`px-4 py-2 text-xs rounded-xl border transition-all cursor-pointer ${
                          theme === "dark"
                            ? "bg-white text-black border-white"
                            : "bg-white/[0.01] border-white/5 text-gray-400 hover:border-white/10"
                        }`}
                      >
                        AMOLED Black (Recommended)
                      </button>
                      <button
                        onClick={() => handleThemeChange("light")}
                        className={`px-4 py-2 text-xs rounded-xl border transition-all cursor-pointer ${
                          theme === "light"
                            ? "bg-[#333130] text-white border-[#333130]"
                            : "bg-white/[0.01] border-white/5 text-gray-400 hover:border-white/10"
                        }`}
                      >
                        Cozy Warm Light
                      </button>
                    </div>
                  </div>

                  {/* Ambience Audio selectors */}
                  <div className="space-y-2">
                    <label className="text-xs font-mono text-gray-400 uppercase tracking-wider block">Background Soundtrack & Particles</label>
                    <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
                      {["Midnight", "Rain", "Thunderstorm", "Night Train", "Calm Air"].map((m) => (
                        <button
                          key={m}
                          onClick={() => handleAmbientChange(m as AmbientMode)}
                          className={`py-2 text-xs rounded-xl border transition-all truncate cursor-pointer ${
                            ambientMode === m
                              ? "bg-indigo-500/10 text-indigo-300 border-indigo-500/40"
                              : "bg-white/[0.01] border-white/5 text-gray-400 hover:border-white/10"
                          }`}
                        >
                          {m}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Push reminders mockup simulation panel */}
                  <div className="space-y-2 pt-4 border-t border-white/5">
                    <label className="text-xs font-mono text-gray-400 uppercase tracking-wider block border-indigo-400">Atmospheric notification tests</label>
                    <p className="text-gray-400 text-xs leading-relaxed max-w-md font-light">
                      Simulate a safe, non-toxic, caring push notification reminder sent from Brother directly onto the screen window.
                    </p>
                    <button
                      onClick={triggerRandomSafeNotification}
                      id="settings_btn_test_notification"
                      className="mt-2 px-4 py-2.5 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl text-xs font-medium text-slate-100 transition-all cursor-pointer"
                    >
                      Trigger Notification Test
                    </button>
                  </div>

                  {/* Clear memory cache panel */}
                  <div className="space-y-2 pt-4 border-t border-white/5">
                    <label className="text-xs font-mono text-rose-400 uppercase tracking-wider block">Danger section</label>
                    <p className="text-gray-400 text-xs leading-relaxed font-light">
                      This will erase your chat history buffers and journaling sheets from your account database sheets forever.
                    </p>
                    <button
                      onClick={handleClearCache}
                      id="settings_btn_clear_data"
                      className="px-4 py-2.5 bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 rounded-xl text-xs font-semibold border border-rose-500/20 transition-all cursor-pointer"
                    >
                      Reset App Account Memory
                    </button>
                  </div>

                </div>

              </div>
            )}

          </main>

          {/* Real Mobile Nav Floor updated with "Shield" tab */}
          {!(isChatImmersionMode && activeTab === "brother") && (
            <nav className="fixed bottom-0 inset-x-0 h-20 bg-black/95 backdrop-blur-3xl border-t border-white/5 flex items-center justify-around px-2 pb-2 z-30 flex-nowrap overflow-x-auto select-none">
            
            <button
              onClick={() => setActiveTab("home")}
              id="navigation_button_home"
              className={`flex flex-col items-center justify-center p-2 rounded-xl transition-all cursor-pointer ${
                activeTab === "home" ? "text-indigo-400 animate-pulse" : "text-gray-500 hover:text-gray-300"
              }`}
            >
              <Moon size={18} />
              <span className="text-[9px] uppercase tracking-wider mt-1 block font-semibold">Home</span>
            </button>

            <button
              onClick={() => setActiveTab("brother")}
              id="navigation_button_brother"
              className={`flex flex-col items-center justify-center p-2 rounded-xl transition-all relative cursor-pointer ${
                activeTab === "brother" ? "text-indigo-400 animate-pulse" : "text-gray-500 hover:text-gray-300"
              }`}
            >
              <Sparkles size={18} />
              <span className="text-[9px] uppercase tracking-wider mt-1 block font-semibold">Brother</span>
              <span className="absolute top-1.5 right-2 w-1.5 h-1.5 rounded-full bg-emerald-500" />
            </button>

            <button
              onClick={() => setActiveTab("journal")}
              id="navigation_button_journal"
              className={`flex flex-col items-center justify-center p-2 rounded-xl transition-all cursor-pointer ${
                activeTab === "journal" ? "text-indigo-400 animate-pulse" : "text-gray-500 hover:text-gray-300"
              }`}
            >
              <BookOpen size={18} />
              <span className="text-[9px] uppercase tracking-wider mt-1 block font-semibold">Journal</span>
            </button>

            <button
              onClick={() => {
                setActiveTab("shield");
                _resetShowerSettings();
              }}
              id="navigation_button_survival"
              className={`flex flex-col items-center justify-center p-2 rounded-xl transition-all cursor-pointer ${
                activeTab === "shield" ? "text-indigo-400 animate-pulse" : "text-gray-500 hover:text-gray-300"
              }`}
            >
              <Shield size={18} />
              <span className="text-[9px] uppercase tracking-wider mt-1 block font-semibold">Shield</span>
            </button>

            <button
              onClick={() => setActiveTab("journey")}
              id="navigation_button_journey"
              className={`flex flex-col items-center justify-center p-2 rounded-xl transition-all cursor-pointer ${
                activeTab === "journey" ? "text-indigo-400 animate-pulse" : "text-gray-500 hover:text-gray-300"
              }`}
            >
              <Activity size={18} />
              <span className="text-[9px] uppercase tracking-wider mt-1 block font-semibold">Journey</span>
            </button>

            <button
              onClick={() => setActiveTab("settings")}
              id="navigation_button_settings"
              className={`flex flex-col items-center justify-center p-2 rounded-xl transition-all cursor-pointer ${
                activeTab === "settings" ? "text-indigo-400 animate-pulse" : "text-gray-500 hover:text-gray-300"
              }`}
            >
              <Sliders size={18} />
              <span className="text-[9px] uppercase tracking-wider mt-1 block font-semibold">Settings</span>
            </button>

          </nav>
          )}

        </div>
      )}

      {/* Extreme Full-screen Emergency Overlay Shield */}
      <EmergencyOverlay 
        isActive={isEmergencyActive} 
        onClose={() => setIsEmergencyActive(false)} 
        username={username}
      />
    </div>
  );

  // Sync helpers to avoid state infinite snaps
  function handleAmbientChange(mode: AmbientMode) {
    setAmbientMode(mode);
    updateUserProfileValue({ ambientMode: mode });
  }

  function handleThemeChange(newTheme: "dark" | "light") {
    setTheme(newTheme);
    updateUserProfileValue({ theme: newTheme });
  }

  function handleUsernameChange(newName: string) {
    setUsername(newName);
    updateUserProfileValue({ username: newName });
  }

  function handleMuteAction(newUrges: number) {
    setUrgesSurvived(newUrges);
    updateUserProfileValue({ urgesSurvived: newUrges });
  }
}
