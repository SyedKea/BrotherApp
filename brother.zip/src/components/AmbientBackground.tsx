import React, { useEffect, useState } from "react";
import { AmbientMode } from "../types";

interface AmbientProps {
  mode: AmbientMode;
  isLightMode: boolean;
  isNightAtmosphere: boolean;
  isFirstDayCelebrationActive?: boolean;
}

export default function AmbientBackground({ 
  mode, 
  isLightMode, 
  isNightAtmosphere,
  isFirstDayCelebrationActive = false
}: AmbientProps) {
  const [particles, setParticles] = useState<{ id: number; top: number; left: number; size: number; duration: number; delay: number }[]>([]);
  const [lightning, setLightning] = useState(false);

  // Generate slow floating particles once and reuse
  useEffect(() => {
    const list = Array.from({ length: 24 }).map((_, i) => ({
      id: i,
      top: Math.random() * 100,
      left: Math.random() * 100,
      size: Math.random() * 3 + 1,
      duration: Math.random() * 20 + 20,
      delay: Math.random() * -20,
    }));
    setParticles(list);
  }, []);

  // Lightning effect for the Thunderstorm mode
  useEffect(() => {
    if (mode !== "Thunderstorm") return;
    if (isFirstDayCelebrationActive) return; // Peace during celebration

    const triggerLightning = () => {
      setLightning(true);
      setTimeout(() => setLightning(false), 200 + Math.random() * 300);
      
      if (Math.random() > 0.5) {
        setTimeout(() => {
          setLightning(true);
          setLightning(false);
        }, 500);
      }
    };

    const interval = setInterval(() => {
      if (Math.random() > 0.6) {
        triggerLightning();
      }
    }, 9000);

    return () => clearInterval(interval);
  }, [mode, isFirstDayCelebrationActive]);

  // Determine background color gradients
  const getGradient = () => {
    if (isFirstDayCelebrationActive) {
      return "from-[#2e1502] via-[#0f0e1d] to-[#04020a] animate-pulse duration-[10000ms]"; // cinematic soft golden amber morning sunrise
    }

    if (isLightMode) {
      switch (mode) {
        case "Calm Air":
          return "from-slate-50 via-sky-50 to-amber-50/30";
        case "Rain":
          return "from-slate-100 via-sky-100/50 to-blue-50/20";
        case "Thunderstorm":
          return "from-slate-100 via-zinc-200/80 to-indigo-100";
        case "Night Train":
          return "from-stone-100 via-amber-50/20 to-slate-200";
        case "Midnight":
        default:
          return "from-slate-50 via-blue-50 to-zinc-100";
      }
    } else {
      // AMOLED and special midnight blends
      const nightMultiplier = isNightAtmosphere ? "to-[#000002]" : "to-[#0b0c10]";
      switch (mode) {
        case "Rain":
          return `from-[#080d19] via-[#04060c] ${nightMultiplier}`;
        case "Thunderstorm":
          return `from-[#0f001b] via-[#040008] ${nightMultiplier}`;
        case "Night Train":
          return `from-[#160e04] via-[#090501] ${nightMultiplier}`;
        case "Calm Air":
          return `from-[#061c28] via-[#030d14] ${nightMultiplier}`;
        case "Midnight":
        default:
          return `from-[#020617] via-[#030712] ${nightMultiplier}`;
      }
    }
  };

  return (
    <div className={`fixed inset-0 w-full h-full -z-50 overflow-hidden transition-colors duration-[3000ms] bg-gradient-to-b ${getGradient()}`}>
      
      {/* Golden morning sun rays overlay during celebration */}
      {isFirstDayCelebrationActive && (
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_bottom,_rgba(245,158,11,0.07),_transparent_65%)] mix-blend-screen pointer-events-none z-0 animate-pulse duration-[6000ms]" />
      )}

      {/* Light flash layer for lightning */}
      {lightning && (
        <div className="absolute inset-0 bg-white/10 z-0 pointer-events-none transition-opacity duration-75" />
      )}

      {/* Animated Fog layer */}
      <div className={`absolute inset-0 pointer-events-none mix-blend-screen overflow-hidden transition-opacity duration-[3000ms] ${
        isFirstDayCelebrationActive ? "opacity-10" : "opacity-40"
      }`}>
        <div className="absolute top-1/4 w-[200vw] h-[150vh] bg-[radial-gradient(ellipse_at_center,_rgba(255,255,255,0.015),_transparent_70%)] animate-fog-left" />
        <div className="absolute top-0 w-[200vw] h-[150vh] bg-[radial-gradient(ellipse_at_center,_rgba(255,255,255,0.01),_transparent_60%)] animate-fog-right" />
      </div>

      {/* Rain drop mesh overlay */}
      {!isFirstDayCelebrationActive && (mode === "Rain" || mode === "Thunderstorm") && (
        <div className="absolute inset-0 pointer-events-none z-0 opacity-25">
          <div className="absolute inset-0 bg-[linear-gradient(171deg,rgba(255,255,255,0.04)_2px,transparent_2px)] bg-[size:100px_350px] animate-[slide-down_4s_linear_infinite]" />
          <div className="absolute inset-0 bg-[linear-gradient(173deg,rgba(255,255,255,0.03)_1.5px,transparent_1.5px)] bg-[size:140px_250px] animate-[slide-down_3.2s_linear_infinite]" />
          <div className="absolute inset-0 bg-[linear-gradient(175deg,rgba(200,220,255,0.04)_1px,transparent_1px)] bg-[size:80px_450px] animate-[slide-down_5s_linear_infinite]" />
        </div>
      )}

      {/* Night Train background light streams */}
      {!isFirstDayCelebrationActive && mode === "Night Train" && (
        <div className="absolute inset-x-0 bottom-1/4 h-24 pointer-events-none z-0 overflow-hidden opacity-30">
          <div className="absolute top-4 left-[-10vw] w-[40vw] h-[2px] bg-gradient-to-r from-transparent via-amber-400 to-transparent blur-[1px] animate-[train-light-stream_12s_linear_infinite]" />
          <div className="absolute top-12 left-[-15vw] w-[30vw] h-[1px] bg-gradient-to-r from-transparent via-amber-300 to-transparent blur-[2px] animate-[train-light-stream2_16s_linear_infinite_2s]" />
          <div className="absolute top-2 left-[-12vw] w-[50vw] h-[1.5px] bg-gradient-to-r from-transparent via-orange-400 to-transparent blur-[1px] animate-[train-light-stream_9s_linear_infinite_4s]" />
          <div className="absolute top-20 left-[-20vw] w-[25vw] h-[2px] bg-gradient-to-r from-transparent via-yellow-200 to-transparent blur-[3px] animate-[train-light-stream2_22s_linear_infinite_1s]" />
        </div>
      )}

      {/* Floating dust/stardust particles */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden z-0">
        {particles.map((p) => (
          <div
            key={p.id}
            className={`absolute rounded-full transition-all duration-[3000ms] ${
              isFirstDayCelebrationActive 
                ? "bg-amber-400/40 shadow-[0_0_10px_rgba(251,191,36,0.5)]" 
                : isLightMode 
                  ? "bg-slate-400/20" 
                  : "bg-white/10"
            }`}
            style={{
              top: `${p.top}%`,
              left: `${p.left}%`,
              width: `${p.size + (isFirstDayCelebrationActive ? 1.5 : 0)}px`,
              height: `${p.size + (isFirstDayCelebrationActive ? 1.5 : 0)}px`,
              animation: `float-particle ${p.duration * (isFirstDayCelebrationActive ? 4 : 1)}s linear infinite`,
              animationDelay: `${p.delay}s`,
            }}
          />
        ))}
      </div>

      <style>{`
        @keyframes float-particle {
          0% { transform: translateY(0) translateX(0) scale(1); opacity: 0; }
          10% { opacity: 0.7; }
          90% { opacity: 0.7; }
          100% { transform: translateY(-120px) translateX(40px) scale(0.6); opacity: 0; }
        }
        @keyframes slide-down {
          0% { transform: translateY(-100%); }
          100% { transform: translateY(100%); }
        }
        @keyframes train-light-stream {
          0% { transform: translateX(-100%); }
          100% { transform: translateX(300%); }
        }
        @keyframes train-light-stream2 {
          0% { transform: translateX(300%); }
          100% { transform: translateX(-100%); }
        }
      `}</style>
    </div>
  );
}
