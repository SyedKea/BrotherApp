import React, { useState } from "react";
import { 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  signInWithPopup, 
  GoogleAuthProvider, 
  sendPasswordResetEmail 
} from "firebase/auth";
import { auth, db } from "../firebase";
import { doc, getDoc, setDoc } from "firebase/firestore";
import { Shield, Sparkles, Moon, LifeBuoy, AlertCircle, Eye, EyeOff } from "lucide-react";

interface AuthProps {
  onAuthSuccess: (uid: string, profile: any) => void;
}

export default function AuthView({ onAuthSuccess }: AuthProps) {
  const [isSignUp, setIsSignUp] = useState(false);
  const [isResetMode, setIsResetMode] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [username, setUsername] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const getCleanErrorMessage = (err: any) => {
    const code = err?.code || "";
    if (code === "auth/user-not-found" || code === "auth/wrong-password") {
      return "those keys don't seem to match our sheets. check the email or password.";
    }
    if (code === "auth/email-already-in-use") {
      return "that email is already connected. try logging in instead.";
    }
    if (code === "auth/weak-password") {
      return "brother, use a slightly stronger password to shield your thoughts (at least 6 characters).";
    }
    if (code === "auth/invalid-email") {
      return "that doesn't look like a real email format, man.";
    }
    return err?.message || "an unexpected error occurred. let's try again.";
  };

  const syncOrCreateUserProfile = async (uid: string, fallbackEmail: string) => {
    try {
      const userRef = doc(db, "users", uid);
      const userSnap = await getDoc(userRef);

      if (userSnap.exists()) {
        const data = userSnap.data();
        onAuthSuccess(uid, data);
      } else {
        // Create initial user profile sheet
        const emailPrefix = fallbackEmail.split("@")[0] || "brother";
        const cleanName = username.trim() || emailPrefix;
        const initialProfile = {
          username: cleanName,
          ambientMode: "Midnight",
          theme: "dark",
          urgesSurvived: 0, 
          honestyCount: 0,
          recoveryDays: 0,
          honestyStreak: 0,
          consistency: 0,
          memorySummary: "User joined the circle tonight.",
          createdAt: new Date().toISOString()
        };
        await setDoc(userRef, initialProfile);
        onAuthSuccess(uid, initialProfile);
      }
    } catch (err: any) {
      console.error("Error checking/creating user profile:", err);
      // Fallback local login if Firestore has any transient permissions latency
      onAuthSuccess(uid, {
        username: username || "brother",
        ambientMode: "Midnight",
        theme: "dark",
        urgesSurvived: 0,
        honestyCount: 0,
        recoveryDays: 0,
        honestyStreak: 0,
        consistency: 0,
        memorySummary: "User signed in (local profile)."
      });
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setMessage(null);

    if (!email.trim() || (!isResetMode && !password.trim())) {
      setError("whisper both credentials to proceed, man.");
      return;
    }

    setLoading(true);
    try {
      if (isResetMode) {
        await sendPasswordResetEmail(auth, email.trim());
        setMessage("i've quietly dispatched a reset link to your email. take a look.");
        setLoading(false);
        return;
      }

      if (isSignUp) {
        if (!username.trim()) {
          setError("give me a name or nickname so I know what to call you, brother.");
          setLoading(false);
          return;
        }
        const userCred = await createUserWithEmailAndPassword(auth, email.trim(), password);
        await syncOrCreateUserProfile(userCred.user.uid, userCred.user.email || "");
      } else {
        const userCred = await signInWithEmailAndPassword(auth, email.trim(), password);
        await syncOrCreateUserProfile(userCred.user.uid, userCred.user.email || "");
      }
    } catch (err: any) {
      setError(getCleanErrorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleSignIn = async () => {
    setError(null);
    setMessage(null);
    setLoading(true);
    try {
      const provider = new GoogleAuthProvider();
      // Configure popup provider parameters if any
      const userCred = await signInWithPopup(auth, provider);
      await syncOrCreateUserProfile(userCred.user.uid, userCred.user.email || "");
    } catch (err: any) {
      setError(getCleanErrorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-[100dvh] w-full flex flex-col justify-center items-center px-4 py-12 relative overflow-y-auto bg-[#030305]/90 transition-all duration-[2000ms]">
      {/* Decorative calm atmospheric glows */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[550px] h-[550px] bg-[radial-gradient(ellipse_at_center,_rgba(99,102,241,0.06),_transparent_70%)] pointer-events-none" />
      <div className="absolute bottom-10 left-10 w-96 h-96 bg-[radial-gradient(circle_at_center,_rgba(168,85,247,0.03),_transparent_60%)] pointer-events-none" />

      {/* Main card */}
      <div className="w-full max-w-md glass-panel p-8 sm:p-10 rounded-3xl border border-white/5 relative bg-black/40 backdrop-blur-3xl shadow-[0_20px_50px_rgba(0,0,0,0.5)] glow-purple">
        
        {/* Top Branding Header */}
        <div className="flex flex-col items-center space-y-4 text-center pb-6">
          <div className="relative w-12 h-12 rounded-2xl bg-gradient-to-tr from-purple-600 via-indigo-600 to-indigo-500 flex items-center justify-center font-bold tracking-tighter text-white text-xl shadow-lg shadow-indigo-600/20">
            B
            <span className="absolute -top-1 -right-1 w-3 h-3 bg-indigo-400 rounded-full animate-pulse border-2 border-black" />
          </div>
          <div className="space-y-1">
            <span className="text-[10px] font-mono tracking-[0.4em] text-indigo-400 uppercase font-bold block">
              Midnight Companion Circle
            </span>
            <h2 className="text-2xl font-extralight tracking-tight text-white leading-tight">
              {isResetMode 
                ? "Restore peace" 
                : isSignUp 
                  ? "Take a seat by the hearth" 
                  : "Welcome back to the safe room"}
            </h2>
            <p className="text-gray-400 text-xs max-w-sm mt-1 leading-relaxed">
              {isResetMode 
                ? "let's recover your sanctuary access" 
                : isSignUp 
                  ? "no judgment, no streak tickers. just an elder brother having your back." 
                  : "the storm outside remains out there. let's sit in here."}
            </p>
          </div>
        </div>

        {/* Display response messages */}
        {error && (
          <div className="mb-5 p-3.5 bg-rose-500/10 border border-rose-500/30 text-rose-300 rounded-xl text-xs flex items-start space-x-2.5 leading-normal animate-pulse">
            <AlertCircle size={14} className="mt-0.5 flex-shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {message && (
          <div className="mb-5 p-3.5 bg-indigo-500/10 border border-indigo-500/30 text-indigo-300 rounded-xl text-xs flex items-start space-x-2.5 leading-normal">
            <Sparkles size={14} className="mt-0.5 flex-shrink-0 text-amber-300" />
            <span>{message}</span>
          </div>
        )}

        {/* Email/password submission */}
        <form onSubmit={handleSubmit} className="space-y-4">
          
          {isSignUp && !isResetMode && (
            <div className="space-y-1.5 animate-[fadeIn_0.5s_ease]">
              <label className="text-[10px] font-mono uppercase tracking-wider text-gray-500 block">
                What should brother call you?
              </label>
              <input
                type="text"
                placeholder="nickname, initials, or name..."
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full p-3.5 rounded-xl text-sm glass-input text-white"
                required={isSignUp}
              />
            </div>
          )}

          <div className="space-y-1.5">
            <label className="text-[10px] font-mono uppercase tracking-wider text-gray-500 block">
              Email Address
            </label>
            <input
              type="email"
              placeholder="name@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full p-3.5 rounded-xl text-sm glass-input text-white"
              required
            />
          </div>

          {!isResetMode && (
            <div className="space-y-1.5">
              <div className="flex justify-between items-center">
                <label className="text-[10px] font-mono uppercase tracking-wider text-gray-500 block">
                  Password
                </label>
                {!isSignUp && (
                  <button 
                    type="button" 
                    onClick={() => { setIsResetMode(true); setError(null); setMessage(null); }}
                    className="text-[10px] text-indigo-400 hover:text-indigo-300 font-mono transition-colors"
                  >
                    forgot password?
                  </button>
                )}
              </div>
              <div className="relative flex items-center">
                <input
                  type={showPassword ? "text" : "password"}
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full p-3.5 pr-11 rounded-xl text-sm glass-input text-white"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3.5 text-gray-400 hover:text-slate-200 transition-colors"
                >
                  {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full mt-2 py-3.5 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-medium text-sm tracking-wider rounded-xl transition-all duration-300 shadow-md active:scale-98 flex items-center justify-center space-x-2 cursor-pointer disabled:opacity-50 disabled:pointer-events-none"
          >
            {loading ? (
              <span className="w-5 h-5 rounded-full border-2 border-white/20 border-t-white animate-spin" />
            ) : isResetMode ? (
              <span>Send Recovery Link</span>
            ) : isSignUp ? (
              <span>Sign Up & Sync Security</span>
            ) : (
              <span>Enter Cozy Room</span>
            )}
          </button>
        </form>

        {/* Divider */}
        {!isResetMode && (
          <div className="my-6 flex items-center justify-between text-[10px] font-mono text-gray-600 block">
            <span className="w-[38%] h-[1px] bg-white/5" />
            <span>OR SHIELD VIA</span>
            <span className="w-[38%] h-[1px] bg-white/5" />
          </div>
        )}

        {/* Google sign-in option */}
        {!isResetMode && (
          <button
            type="button"
            onClick={handleGoogleSignIn}
            disabled={loading}
            className="w-full py-3.5 bg-white/5 hover:bg-white/10 active:bg-white/15 border border-white/10 hover:border-white/20 text-slate-100 rounded-xl text-sm font-medium flex items-center justify-center space-x-3 transition-all duration-300 cursor-pointer disabled:opacity-50"
          >
            <svg className="w-4 h-4 text-white" viewBox="0 0 24 24">
              <path fill="currentColor" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
              <path fill="currentColor" fillRule="evenodd" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" clipRule="evenodd" />
              <path fill="currentColor" fillRule="evenodd" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l3.66-2.85z" clipRule="evenodd" />
              <path fill="currentColor" fillRule="evenodd" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.85c.87-2.6 3.3-4.53 6.16-4.53z" clipRule="evenodd" />
            </svg>
            <span>Continue with Google</span>
          </button>
        )}

        {/* Footer Toggle Switches */}
        <div className="pt-6 mt-4 border-t border-white/5 text-center">
          {isResetMode ? (
            <button
              onClick={() => { setIsResetMode(false); setError(null); setMessage(null); }}
              className="text-xs text-purple-400 hover:text-purple-300 font-medium transition-colors"
            >
              ← back to cabin doors
            </button>
          ) : (
            <p className="text-xs text-gray-500 leading-normal">
              {isSignUp ? "already registered with us?" : "new to this midnight safety circle?"}{" "}
              <button
                onClick={() => { setIsSignUp(!isSignUp); setError(null); setMessage(null); }}
                className="text-purple-400 hover:text-purple-300 font-semibold underline underline-offset-4 transition-colors"
              >
                {isSignUp ? "Login here" : "Claim your seat"}
              </button>
            </p>
          )}
        </div>

      </div>

      {/* Philosophy Footnote */}
      <div className="mt-8 text-center text-[10px] font-mono text-gray-600 flex items-center space-x-2">
        <LifeBuoy size={11} className="text-purple-500/40" />
        <span>BROTHER keeps your thoughts. Locked. Transmitted privately. No spyware.</span>
      </div>
    </div>
  );
}
