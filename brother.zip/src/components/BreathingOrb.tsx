import React, { useState, useEffect } from "react";

interface BreathingProps {
  onBreathPhaseChange?: (phase: string) => void;
}

export default function BreathingOrb({ onBreathPhaseChange }: BreathingProps) {
  const [phase, setPhase] = useState<"inhale" | "hold" | "exhale">("inhale");
  const [secondsLeft, setSecondsLeft] = useState(4);

  // Tick the countdown seconds down
  useEffect(() => {
    const interval = setInterval(() => {
      setSecondsLeft((prev) => {
        if (prev <= 1) {
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  // Handle phase changes when countdown reaches zero
  useEffect(() => {
    if (secondsLeft === 0) {
      if (phase === "inhale") {
        setPhase("hold");
        setSecondsLeft(4);
      } else if (phase === "hold") {
        setPhase("exhale");
        setSecondsLeft(4);
      } else {
        setPhase("inhale");
        setSecondsLeft(4);
      }
    }
  }, [secondsLeft, phase]);

  // Safely inform parent about current phase messages
  useEffect(() => {
    if (onBreathPhaseChange) {
      const msg = phase === "inhale" ? "Inhale deeply..." : phase === "hold" ? "Hold..." : "Softly Exhale...";
      const timeout = setTimeout(() => {
        onBreathPhaseChange(msg);
      }, 0);
      return () => clearTimeout(timeout);
    }
  }, [phase, onBreathPhaseChange]);

  const getPhaseColorAndShadow = () => {
    switch (phase) {
      case "hold":
        return "bg-indigo-500/80 shadow-[0_0_80px_rgba(99,102,241,0.5)] scale-110";
      case "exhale":
        return "bg-sky-500/80 shadow-[0_0_80px_rgba(14,165,233,0.4)] scale-90";
      case "inhale":
      default:
        return "bg-purple-500/80 shadow-[0_0_80px_rgba(168,85,247,0.4)] scale-100";
    }
  };

  const getLabel = () => {
    switch (phase) {
      case "hold":
        return "Hold";
      case "exhale":
        return "Let Go";
      case "inhale":
      default:
        return "Inhale";
    }
  };

  return (
    <div className="flex flex-col items-center justify-center space-y-6 select-none my-8">
      {/* Outer sizing container */}
      <div className="relative w-64 h-64 flex items-center justify-center">
        {/* Decorative expand aura */}
        <div className={`absolute inset-0 rounded-full border border-purple-500/20 animate-ping opacity-45 duration-[4000ms]`} />
        
        {/* Secondary ripple border */}
        <div className={`absolute -inset-4 rounded-full border border-white/5 transition-transform duration-[4000ms] ${
          phase === "inhale" ? "scale-105" : phase === "hold" ? "scale-115" : "scale-95"
        }`} />

        {/* Core Breathing Orb with spring scales */}
        <div className={`w-44 h-44 rounded-full flex flex-col items-center justify-center transition-all duration-[4000ms] ease-in-out ${getPhaseColorAndShadow()}`}>
          <span className="text-white text-2xl font-semibold tracking-wide capitalize">{getLabel()}</span>
          <span className="text-white/80 font-mono text-sm mt-1">{secondsLeft}s</span>
        </div>
      </div>
      
      {/* Instructional text styling */}
      <div className="text-center">
        <p className="text-gray-400 text-sm max-w-[250px] mx-auto tracking-wide leading-relaxed">
          {phase === "inhale" && "Breathe in through your nose, expanding your stomach."}
          {phase === "hold" && "Relax your neck and shoulders, let the breath settle."}
          {phase === "exhale" && "Release slowly, allowing your muscle tension to slide off."}
        </p>
      </div>
    </div>
  );
}
