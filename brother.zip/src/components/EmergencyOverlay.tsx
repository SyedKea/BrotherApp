import React, { useState, useEffect } from "react";
import BreathingOrb from "./BreathingOrb";
import { X, ShieldAlert, Heart, RefreshCw, Sparkles } from "lucide-react";

interface EmergencyOverlayProps {
  onClose: () => void;
  isActive: boolean;
  username: string;
}

const GROUNDING_PROMPTS = [
  { text: "Look around you. Name 5 things you can see right now.", subtitle: "A desk, a shadow on the wall, your hands..." },
  { text: "Notice 4 things you can touch. Feel them physically.", subtitle: "The cold table, the fabric of your shirt, your skin..." },
  { text: "Close your eyes for a second. Listen for 3 distinct sounds.", subtitle: "The distant wind, the rain, the hum of your computer..." },
  { text: "Take a deep sniff. Name 2 things you can smell.", subtitle: "The scent of sheets, rain, a lingering cup of coffee..." },
  { text: "Bring awareness to your mouth. Note 1 thing you can taste.", subtitle: "Water, toothpaste, stillness..." },
  { text: "You are here. You are safe. You are in a real room. You do not have to escape.", subtitle: "The urge is just a feeling. It has a beginning, a peak, and an end." },
];

export default function EmergencyOverlay({ isActive, onClose, username }: EmergencyOverlayProps) {
  const [timerCount, setTimerCount] = useState(300); // 5-minute counter
  const [promptIndex, setPromptIndex] = useState(0);
  const [instructionText, setInstructionText] = useState("Inhale deeply...");

  // Rotate grounding cues
  useEffect(() => {
    if (!isActive) return;
    const interval = setInterval(() => {
      setPromptIndex((prev) => (prev + 1) % GROUNDING_PROMPTS.length);
    }, 15000);
    return () => clearInterval(interval);
  }, [isActive]);

  // Countdown timer
  useEffect(() => {
    if (!isActive) return;
    const timer = setInterval(() => {
      setTimerCount((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [isActive]);

  if (!isActive) return null;

  const formatTime = (secs: number) => {
    const min = Math.floor(secs / 60);
    const sec = secs % 60;
    return `${min}:${sec < 10 ? "0" : ""}${sec}`;
  };

  const exercise = GROUNDING_PROMPTS[promptIndex];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#030303]/95 backdrop-blur-2xl transition-all duration-700 ease-in-out block">
      
      {/* Decorative calm backing rings */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-[radial-gradient(ellipse_at_center,_rgba(124,58,237,0.06),_transparent_60%)] pointer-events-none" />

      <div className="absolute top-4 right-4 z-10">
        <button
          onClick={onClose}
          id="close_emergency_mode"
          className="p-3 text-gray-400 bg-white/5 rounded-full hover:bg-white/10 hover:text-white transition-colors"
        >
          <X size={20} />
        </button>
      </div>

      <div className="w-full max-w-lg mx-auto text-center space-y-8 z-15 overflow-y-auto max-h-[92vh] px-2 py-4">
        
        {/* Urgent protection signifier */}
        <div className="flex flex-col items-center space-y-2">
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-rose-500/10 border border-rose-500/20 text-rose-400 text-xs font-mono tracking-wider uppercase animate-pulse">
            <ShieldAlert size={14} />
            <span>5-Min Critical Grounding</span>
          </div>
          <h2 className="text-3xl font-bold tracking-tight text-white mt-3">Stay right here.</h2>
          <p className="text-gray-400 text-sm max-w-sm mt-1">
            {username ? `${username}, you` : "You"} don't have to fight the urges. Just sit here with me and breathe. Five minutes.
          </p>
        </div>

        {/* Deep breathing tool */}
        <div className="glass-panel rounded-2xl p-6 relative overflow-hidden glow-purple border-purple-500/10">
          <span className="absolute top-3 left-4 text-[10px] font-mono uppercase tracking-widest text-purple-400/50">
            Phase Guide
          </span>
          <BreathingOrb onBreathPhaseChange={setInstructionText} />
          
          <div className="text-lg font-medium text-purple-300 transition-all duration-500 min-h-[28px] mt-2">
            {instructionText}
          </div>
        </div>

        {/* Grounding Exercise rotating prompts */}
        <div className="glass-panel p-6 rounded-2xl border-white/5 bg-white/[0.02] text-left transition-all duration-500">
          <div className="flex items-start space-x-3">
            <Heart className="text-rose-400 mt-1 flex-shrink-0" size={18} />
            <div>
              <h4 className="text-white font-medium text-md leading-snug">
                {exercise.text}
              </h4>
              <p className="text-gray-400 text-sm mt-1 leading-relaxed">
                {exercise.subtitle}
              </p>
            </div>
          </div>
          
          <div className="mt-4 flex items-center justify-between text-[11px] font-mono text-gray-500 pt-3 border-t border-white/5">
            <span>Grounding Exercise {promptIndex + 1}/{GROUNDING_PROMPTS.length}</span>
            <button
              id="next_grounding_exercise"
              onClick={() => setPromptIndex((prev) => (prev + 1) % GROUNDING_PROMPTS.length)}
              className="flex items-center space-x-1 text-purple-400 hover:text-purple-300 transition-colors"
            >
              <RefreshCw size={10} />
              <span>Next prompt</span>
            </button>
          </div>
        </div>

        {/* 5-minute countdown and reassuring tags */}
        <div className="flex items-center justify-between max-w-sm mx-auto pt-2">
          <div className="text-left">
            <span className="text-[10px] font-mono tracking-wider text-gray-500 block uppercase">
              Time remaining
            </span>
            <span className="text-3xl font-mono font-bold text-white tracking-widest">
              {formatTime(timerCount)}
            </span>
          </div>

          <div className="text-right">
            <button
              onClick={onClose}
              id="safe_survival_button"
              className="px-6 py-3 rounded-full bg-white text-black font-medium text-sm hover:bg-neutral-200 active:scale-95 transition-all shadow-lg shadow-white/5"
            >
              I feel safe now
            </button>
          </div>
        </div>

      </div>
    </div>
  );
}
