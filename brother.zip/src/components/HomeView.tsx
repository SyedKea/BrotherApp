import React from "react";
import { AmbientMode } from "../types";
import { CloudRain, Moon, Star, Compass, Shield, Wind, Sparkles, AlertCircle } from "lucide-react";

interface HomeProps {
  username: string;
  isNight: boolean;
  ambientMode: AmbientMode;
  setAmbientMode: (mode: AmbientMode) => void;
  onNavigateToTab: (tab: string) => void;
  onTriggerEmergency: () => void;
  moodValue: string;
  setMoodValue: (mood: string) => void;
}

const INSIGHT_QUOTES = [
  "You are not failing. You are just exhausted from carrying things with the sound turned down.",
  "The urge is just a passenger. Let it sit in the backseat, but don't let it drive.",
  "You don't have to carry your family, your future, and your failures all in one single midnight.",
  "It is okay to be tired, brother. It is okay to not have it figured out yet.",
  "Shame is a slow burn. Honesty is the cool water that puts it out.",
];

export default function HomeView({
  username,
  isNight,
  ambientMode,
  setAmbientMode,
  onNavigateToTab,
  onTriggerEmergency,
  moodValue,
  setMoodValue,
}: HomeProps) {
  // Get ambient details
  const getAmbientText = (mode: AmbientMode) => {
    switch (mode) {
      case "Rain": return { icon: <CloudRain size={16} />, phrase: "Rain on the glass" };
      case "Thunderstorm": return { icon: <Wind size={16} />, phrase: "Distant roaring sky" };
      case "Night Train": return { icon: <Compass size={16} />, phrase: "Rhythm of the rails" };
      case "Calm Air": return { icon: <Wind size={16} />, phrase: "Still morning air" };
      case "Midnight":
      default:
        return { icon: <Moon size={16} />, phrase: "Quiet stardust sky" };
    }
  };

  const getEnvironmentalStory = () => {
    const isHeavy = moodValue === "heavy" || moodValue === "lonely" || moodValue === "anxious" || moodValue === "overthinking" || moodValue === "numb";
    const userDisplay = username || "brother";
    
    switch (ambientMode) {
      case "Rain":
        if (isHeavy) {
          return `a cold midnight drizzle streams down the window frame. the night is heavy, ${userDisplay}, but inside, a single soft match is struck for you here. you don't have to carry these cold drafts alone tonight.`;
        }
        return "transparent rain drops are pattering softly against the glass. the rhythmic sounds of the storm are washing the slate quiet. you are safe, fully sheltered, and breathe in the moist air.";
      case "Thunderstorm":
        if (isHeavy) {
          return `distant lightning outlines a roaring midnight sky, casting deep shadows across the room. the pressure feels immense, ${userDisplay}, but storms always break. i'm staying awake with you through the rumbling.`;
        }
        return "a deep indigo static energy hums through the air outside. you've gathered your thoughts, choosing to watch the lightning from a clean slate rather than running into the rain.";
      case "Night Train":
        if (isHeavy) {
          return "chugging trains cut through the quiet plains, their warm amber beams lighting up the iron tracks. you feel isolated in this empty train car, but we are traveling this route together, one quiet mile at a time.";
        }
        return "the slow, soothing rhythm of the iron rails is humming in the baseline. you are moving steadily through the dark hours. let the weight of the day drift off with the passing lights.";
      case "Calm Air":
        if (isHeavy) {
          return `a silent morning breeze is slowly filtering through the cracked frame. your thoughts are spinning, ${userDisplay}, but the ambient pink-blue horizon is beginning to peek over the clouds. take a deep breath.`;
        }
        return "the fresh sky is breaking clear. the heavy morning mist is dissolving, revealing a quiet, beautiful dawn. you've walked through the thickest part of the night. feel the still air on your hands.";
      case "Midnight":
      default:
        if (isHeavy) {
          return `minimal, slow stardust floats through a quiet, dark room. when the silence of the night gets too loud, ${userDisplay}, shut down the glowing feeds, close the door, and let your body ground itself.`;
        }
        return "a deep celestial slate frames a quiet midnight sky. there are no metrics, no tasks to complete, and absolutely no expectations of you here. just breathe, and let yourself exist.";
    }
  };

  const ambientInfo = getAmbientText(ambientMode);

  return (
    <div className="space-y-8 pb-10">
      
      {/* Dynamic atmospheric header greeting */}
      <div className="space-y-2 text-center md:text-left mt-4">
        <span className="text-xs font-mono tracking-widest text-purple-400/80 uppercase block">
          {isNight ? "Late Night Companion" : "Deep Breath Companion"}
        </span>
        <h1 className="text-3xl sm:text-4xl font-bold text-white tracking-tight leading-none mt-1 select-none">
          {isNight ? "Hey, brother. Long night?" : `Welcome back, ${username || "brother"}.`}
        </h1>
        <p className="text-gray-400 text-sm max-w-md mt-2 leading-relaxed">
          {isNight 
            ? "The world is asleep. You don't have to suppress anything here. I'm awake with you."
            : "Take a second to step back from the exhaust, the screens, and the speed."}
        </p>
      </div>

      {/* Atmospheric environmental storytelling card - No Tech-Larping, pure poetry */}
      <div className="glass-panel p-6 rounded-2xl border-white/5 bg-gradient-to-tr from-white/[0.01] to-[#0a0a14]/60 backdrop-blur-md relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/[0.02] rounded-full blur-3xl pointer-events-none" />
        <div className="space-y-2 select-none">
          <div className="flex items-center space-x-2">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-[10px] font-mono tracking-widest text-[#a5b4fc] uppercase">Atmospheric Condition</span>
          </div>
          <p className="text-slate-300 font-serif text-sm italic leading-relaxed">
            "{getEnvironmentalStory()}"
          </p>
          <span className="text-[10px] text-gray-500 font-mono block pt-1">— current cabin atmosphere</span>
        </div>
      </div>

      {/* Heavy-duty global trigger banner for emergency assistance */}
      <div className="glass-panel p-5 rounded-2xl border-rose-500/10 flex flex-col sm:flex-row items-center justify-between gap-4 relative overflow-hidden backdrop-blur-xl bg-gradient-to-r from-rose-500/[0.03] to-purple-500/[0.03]">
        <div className="absolute top-0 right-0 w-24 h-24 bg-rose-500/5 rounded-full blur-2xl pointer-events-none" />
        <div className="flex items-start space-x-3 text-center sm:text-left">
          <div className="p-3 bg-rose-500/10 rounded-full text-rose-400 flex-shrink-0 mx-auto sm:mx-0">
            <AlertCircle size={20} className="animate-pulse" />
          </div>
          <div className="space-y-1">
            <h3 className="text-white font-medium text-md">Struggling with intense urges or distress?</h3>
            <p className="text-gray-400 text-xs leading-relaxed max-w-sm">
              Activate the immediate containment shield. Together we'll ground your nervous system.
            </p>
          </div>
        </div>
        <button
          onClick={onTriggerEmergency}
          id="home_emergency_containment_btn"
          className="w-full sm:w-auto px-6 py-3 bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 font-medium rounded-full text-xs tracking-wider border border-rose-500/30 transition-all duration-300 transform active:scale-95 cursor-pointer"
        >
          Open Shield Page
        </button>
      </div>

      {/* Gentle mood validation selector */}
      <div className="space-y-3">
        <h3 className="text-sm font-mono text-gray-400 uppercase tracking-wider">How heavy are today's thoughts?</h3>
        
        <div className="grid grid-cols-2 xs:grid-cols-3 sm:grid-cols-6 gap-3">
          {[
            { id: "heavy", label: "Very Heavy", color: "border-purple-500/30 text-purple-300 hover:bg-purple-500/10" },
            { id: "numb", label: "Numb", color: "border-slate-500/30 text-slate-300 hover:bg-slate-500/10" },
            { id: "anxious", label: "Anxious", color: "border-sky-500/30 text-sky-300 hover:bg-sky-500/10" },
            { id: "lonely", label: "Lonely", color: "border-indigo-500/30 text-indigo-300 hover:bg-indigo-500/10" },
            { id: "overthinking", label: "Spinning", color: "border-amber-500/30 text-amber-300 hover:bg-amber-500/10" },
            { id: "peaceful", label: "Peaceful", color: "border-emerald-500/30 text-emerald-300 hover:bg-emerald-500/10" },
          ].map((m) => (
            <button
              key={m.id}
              onClick={() => setMoodValue(m.id)}
              id={`mood_button_${m.id}`}
              className={`py-3 px-2 text-center text-xs font-medium rounded-xl border transition-all duration-300 cursor-pointer ${
                moodValue === m.id 
                  ? "bg-white text-black border-white shadow-md shadow-white/5" 
                  : `bg-white/[0.02] border-white/5 ${m.color}`
              }`}
            >
              {m.label}
            </button>
          ))}
        </div>
      </div>

      {/* Ambient Audio and Scenery system switcher */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-mono text-gray-400 uppercase tracking-wider">Select Ambient Vibe</h3>
          <span className="text-xs text-purple-400/80 font-mono flex items-center space-x-1">
            {ambientInfo.icon}
            <span className="ml-1 font-medium">{ambientInfo.phrase}</span>
          </span>
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
          {[
            { id: "Midnight", label: "Midnight Sky", desc: "Minimal particles & slow stars", icon: <Moon size={16} /> },
            { id: "Rain", label: "Rainy Night", desc: "Gentle transparent fluid drops", icon: <CloudRain size={16} /> },
            { id: "Thunderstorm", label: "Storm", desc: "Dark purples & deep lightning cues", icon: <Wind size={16} /> },
            { id: "Night Train", label: "Night Train", desc: "Chugging lights & warm amber trail", icon: <Compass size={16} /> },
            { id: "Calm Air", label: "Calm Breeze", desc: "Soothing pink-blue dawn skies", icon: <Star size={16} /> },
          ].map((modeObj) => (
            <button
              key={modeObj.id}
              id={`ambient_select_card_${modeObj.id}`}
              onClick={() => setAmbientMode(modeObj.id as AmbientMode)}
              className={`p-4 rounded-2xl border text-left flex flex-col justify-between space-y-4 transition-all duration-500 cursor-pointer ${
                ambientMode === modeObj.id
                  ? "bg-white/[0.05] border-purple-500/40 shadow-inner"
                  : "bg-white/[0.01] border-white/5 hover:border-white/10 hover:bg-white/[0.02]"
              }`}
            >
              <div className="flex items-center justify-between">
                <span className={`p-2 rounded-lg ${ambientMode === modeObj.id ? 'bg-purple-500/20 text-purple-400' : 'bg-white/5 text-gray-400'}`}>
                  {modeObj.icon}
                </span>
                {ambientMode === modeObj.id && (
                  <span className="w-1.5 h-1.5 rounded-full bg-purple-400 animate-pulse" />
                )}
              </div>
              <div>
                <h4 className="text-white font-medium text-sm">{modeObj.label}</h4>
                <p className="text-gray-400 text-[11px] mt-0.5 leading-snug">{modeObj.desc}</p>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Main companion shortcut cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        
        <div className="glass-panel p-5 rounded-2xl border-white/5 flex flex-col justify-between space-y-4 relative group">
          <div className="space-y-1">
            <h4 className="text-white font-semibold text-lg flex items-center space-x-2">
              <span>Chat with Brother</span>
              <Sparkles size={16} className="text-purple-400" />
            </h4>
            <p className="text-gray-400 text-xs leading-relaxed">
              No pressure. No milestones. Talk to him about your exhausting day, your urges, or the quiet isolation.
            </p>
          </div>
          <button
            onClick={() => onNavigateToTab("brother")}
            id="home_gocard_chat"
            className="w-full py-3 bg-white text-black hover:bg-neutral-200 active:scale-98 text-xs font-semibold rounded-xl text-center tracking-wide transition-all cursor-pointer"
          >
            Start Talking
          </button>
        </div>

        <div className="glass-panel p-5 rounded-2xl border-white/5 flex flex-col justify-between space-y-4 relative">
          <div className="space-y-1">
            <h4 className="text-white font-semibold text-lg flex items-center space-x-2">
              <span>Emotional Journal</span>
              <span className="text-[10px] bg-sky-500/10 text-sky-400 font-mono px-1.5 py-0.5 rounded">Safe Log</span>
            </h4>
            <p className="text-gray-400 text-xs leading-relaxed">
              Dump what you're trying not to feel. Unpack your heavy burdens and let our AI compile actual healing insights.
            </p>
          </div>
          <button
            onClick={() => onNavigateToTab("journal")}
            id="home_gocard_journal"
            className="w-full py-3 bg-white/5 hover:bg-white/10 text-white border border-white/10 text-xs font-medium rounded-xl text-center tracking-wide transition-all cursor-pointer"
          >
            Write What Hurts
          </button>
        </div>

        <div className="glass-panel p-5 rounded-2xl border-white/5 flex flex-col justify-between space-y-4 relative">
          <div className="space-y-1">
            <h4 className="text-white font-semibold text-lg flex items-center space-x-2">
              <span>Survival Tools</span>
              <Shield size={16} className="text-emerald-400" />
            </h4>
            <p className="text-gray-400 text-xs leading-relaxed">
              Ground your body. Cold shower timers, structured breathing, and cognitive walking guides for difficult moments.
            </p>
          </div>
          <button
            onClick={() => onNavigateToTab("shield")}
            id="home_gocard_survival"
            className="w-full py-3 bg-white/5 hover:bg-white/10 text-white border border-white/10 text-xs font-medium rounded-xl text-center tracking-wide transition-all cursor-pointer"
          >
            Access Shield Kits
          </button>
        </div>

      </div>

      {/* Cinematic comforting quotation banner */}
      <div className="relative text-center py-8 px-4 max-w-xl mx-auto border-t border-b border-white/5">
        <span className="text-purple-400/40 text-4xl font-serif absolute -top-1 left-4">“</span>
        <blockquote className="text-gray-300 italic text-md leading-relaxed">
          {INSIGHT_QUOTES[isNight ? 2 : Math.floor(Math.random() * INSIGHT_QUOTES.length)]}
        </blockquote>
        <p className="text-gray-500 text-xs font-mono tracking-wider mt-4">— Brother</p>
      </div>

    </div>
  );
}
