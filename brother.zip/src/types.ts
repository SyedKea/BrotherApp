export interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  text: string;
  timestamp: string;
  isStreamingComplete?: boolean;
  isPinned?: boolean;
  memoryType?: "short" | "medium" | "long";
  pinnedAt?: string;
  threadId?: string;
  threadTitle?: string;
}

export interface JournalEntry {
  id: string;
  content: string;
  date: string;
  mood: "heavy" | "numb" | "anxious" | "lonely" | "overthinking" | "peaceful";
  tags: string[];
  timestamp: number;
}

export type AmbientMode = "Midnight" | "Rain" | "Thunderstorm" | "Night Train" | "Calm Air";

export interface SurvivalTool {
  id: string;
  name: string;
  duration: number; // in seconds
  description: string;
  message: string;
}

export interface AppState {
  chatHistory: ChatMessage[];
  journals: JournalEntry[];
  ambientMode: AmbientMode;
  theme: "dark" | "light" | "system";
  isNightAtmosphere: boolean; // Auto or overridden
  memorySummary: string;
  isEmergencyActive: boolean;
  username: string;
}
