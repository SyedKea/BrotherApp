// Dynamic Web Audio API Synth Engine for BR0THER Sanctuary
// Generates safe, therapeutic, offline-ready ambient soundscapes in-browser.

export type AmbientMode = "Midnight" | "Rain" | "Thunderstorm" | "Night Train" | "Calm Air";

class AmbientAudioEngine {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  
  // Audio sources
  private droneOscs: OscillatorNode[] = [];
  private droneGain: GainNode | null = null;
  private noiseNode: AudioWorkletNode | ScriptProcessorNode | null = null;
  private noiseFilter: BiquadFilterNode | null = null;
  private noiseGain: GainNode | null = null;
  
  // Chords/Chimes Synths
  private chimeTimer: NodeJS.Timeout | null = null;
  private chordTimer: NodeJS.Timeout | null = null;
  private trainTimer: NodeJS.Timeout | null = null;

  private activeMode: AmbientMode = "Midnight";
  private currentVolume: number = 0.3;
  private currentMuted: boolean = false;
  private isInitialized: boolean = false;

  constructor() {
    // Read persisted options
    if (typeof window !== "undefined") {
      const savedVol = localStorage.getItem("brother_ambient_volume");
      if (savedVol !== null) this.currentVolume = parseFloat(savedVol);
      const savedMute = localStorage.getItem("brother_ambient_muted");
      if (savedMute !== null) this.currentMuted = savedMute === "true";
      const savedMode = localStorage.getItem("brother_ambient_mode");
      if (savedMode !== null) this.activeMode = savedMode as AmbientMode;
    }
  }

  public init() {
    if (this.isInitialized) return;
    
    try {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      this.ctx = new AudioContextClass();
      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.value = this.currentMuted ? 0 : this.currentVolume;
      this.masterGain.connect(this.ctx.destination);
      
      this.setupDrones();
      this.setupNoiseGenerators();
      
      this.isInitialized = true;
      this.setMode(this.activeMode, true);
    } catch (err) {
      console.warn("Web Audio API not supported or initialized:", err);
    }
  }

  // Set up low frequency deep background cozy human hum
  private setupDrones() {
    if (!this.ctx || !this.masterGain) return;
    
    this.droneGain = this.ctx.createGain();
    this.droneGain.gain.value = 0.15; // low cozy baseline
    this.droneGain.connect(this.masterGain);

    // Warm detuned low sub oscillators
    const frequencies = [55.0, 55.4, 110.0]; // A1, detuned slot, A2
    frequencies.forEach((freq, idx) => {
      const osc = this.ctx!.createOscillator();
      const gain = this.ctx!.createGain();
      
      osc.type = idx === 2 ? "sine" : "triangle"; // sine wrapper for warmth
      osc.frequency.value = freq;
      
      gain.gain.value = idx === 2 ? 0.4 : 0.6;
      
      // slow warm lfo frequency modulation simulation
      const lfo = this.ctx!.createOscillator();
      const lfoGain = this.ctx!.createGain();
      lfo.frequency.value = 0.1 + idx * 0.05; // very slow wave
      lfoGain.gain.value = 0.05; // subtle variance
      
      lfo.connect(lfoGain);
      lfoGain.connect(osc.frequency);
      lfo.start();
      
      osc.connect(gain);
      gain.connect(this.droneGain!);
      osc.start();
      
      this.droneOscs.push(osc);
    });
  }

  // Create real-time white noise buffer for rain/wind filters
  private setupNoiseGenerators() {
    if (!this.ctx || !this.masterGain) return;

    this.noiseGain = this.ctx.createGain();
    this.noiseGain.gain.value = 0.0; // muted by default, faded dynamically
    this.noiseGain.connect(this.masterGain);

    // Generate White Noise Buffer
    const bufferSize = 2 * this.ctx.sampleRate;
    const noiseBuffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const output = noiseBuffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      output[i] = Math.random() * 2 - 1;
    }

    const noiseSource = this.ctx.createBufferSource();
    noiseSource.buffer = noiseBuffer;
    noiseSource.loop = true;

    // Create high quality multi-stage filters
    this.noiseFilter = this.ctx.createBiquadFilter();
    this.noiseFilter.type = "bandpass";
    this.noiseFilter.Q.value = 1.0;
    this.noiseFilter.frequency.value = 1000;

    noiseSource.connect(this.noiseFilter);
    this.noiseFilter.connect(this.noiseGain);
    noiseSource.start();

    // Noise LFO wind sweep simulation
    const windLfo = this.ctx.createOscillator();
    const windLfoGain = this.ctx.createGain();
    windLfo.frequency.value = 0.04; // extremely slow breeze
    windLfoGain.gain.value = 350; // sweeps cutoff from 650 to 1350 Hz

    windLfo.connect(windLfoGain);
    windLfoGain.connect(this.noiseFilter.frequency);
    windLfo.start();
  }

  // Set current soundtrack mood/mode
  public setMode(mode: AmbientMode, force: boolean = false) {
    this.activeMode = mode;
    localStorage.setItem("brother_ambient_mode", mode);
    
    if (!this.isInitialized) return;
    this.resumeContext();

    this.stopTimers();

    // Smooth fading parameters (1.5s crossfade)
    const now = this.ctx!.currentTime;
    
    if (this.droneGain && this.noiseGain && this.noiseFilter) {
      this.droneGain.gain.setValueAtTime(this.droneGain.gain.value, now);
      this.noiseGain.gain.setValueAtTime(this.noiseGain.gain.value, now);
      
      switch (mode) {
        case "Midnight":
          // Deep cozy pure quiet starlight
          this.droneGain.gain.linearRampToValueAtTime(0.2, now + 2);
          this.noiseGain.gain.linearRampToValueAtTime(0.005, now + 2); // barely noticeable background air
          this.noiseFilter.frequency.setValueAtTime(600, now);
          this.noiseFilter.Q.setValueAtTime(0.5, now);
          this.startChimeGenerator();
          break;
          
        case "Rain":
          // Soft window frame rain drops
          this.droneGain.gain.linearRampToValueAtTime(0.1, now + 2);
          this.noiseGain.gain.linearRampToValueAtTime(0.12, now + 2.5); // beautiful soft rain layer
          this.noiseFilter.frequency.setValueAtTime(800, now);
          this.noiseFilter.Q.setValueAtTime(1.2, now);
          this.startPianoGenerator();
          break;
          
        case "Thunderstorm":
          // Colder, purple heavy lightning rumbler
          this.droneGain.gain.linearRampToValueAtTime(0.15, now + 2);
          this.noiseGain.gain.linearRampToValueAtTime(0.25, now + 2); // strong wind/rain
          this.noiseFilter.frequency.setValueAtTime(500, now);
          this.noiseFilter.Q.setValueAtTime(0.8, now);
          this.startThunderGenerator();
          break;
          
        case "Night Train":
          // Moving reflection train click clacks
          this.droneGain.gain.linearRampToValueAtTime(0.12, now + 2);
          this.noiseGain.gain.linearRampToValueAtTime(0.02, now + 2); // faint rustle
          this.startTrainRhythm();
          break;
          
        case "Calm Air":
          // Softer brighter morning healing air
          this.droneGain.gain.linearRampToValueAtTime(0.08, now + 2);
          this.noiseGain.gain.linearRampToValueAtTime(0.04, now + 2);
          this.noiseFilter.frequency.setValueAtTime(1200, now);
          this.noiseFilter.Q.setValueAtTime(0.4, now);
          this.startCalmAirSwells();
          break;
      }
    }
  }

  // Bell/chime scheduler for Starlight Space Midnight mode
  private startChimeGenerator() {
    const scales = [196.0, 220.0, 261.63, 293.66, 329.63, 392.0, 440.0, 523.25]; // G3, A3, C4, D4, E4, G4, A4, C5
    
    const playChime = () => {
      if (!this.ctx || !this.masterGain || this.activeMode !== "Midnight") return;
      
      const now = this.ctx.currentTime;
      const freq = scales[Math.floor(Math.random() * scales.length)];
      
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const filter = this.ctx.createBiquadFilter();
      
      osc.type = "sine";
      osc.frequency.value = freq;
      
      filter.type = "lowpass";
      filter.frequency.value = 1500;
      filter.Q.value = 7.0; // ringing crystal bells resonance

      gain.gain.setValueAtTime(0, now);
      gain.gain.linearRampToValueAtTime(0.012, now + 0.1); // peaceful, tiny soft spark
      gain.gain.exponentialRampToValueAtTime(0.00001, now + 3.5); // long cozy decay
      
      osc.connect(filter);
      filter.connect(gain);
      gain.connect(this.masterGain);
      
      osc.start(now);
      osc.stop(now + 4);
      
      // Schedule next
      const delay = Math.random() * 4000 + 3000; // random 3-7 seconds
      this.chimeTimer = setTimeout(playChime, delay);
    };

    this.chimeTimer = setTimeout(playChime, 2000);
  }

  // Soft piano scheduler for rainy night modes
  private startPianoGenerator() {
    // Fmaj7, Am9, G6, Em7 notes
    const chords = [
      [174.61, 261.63, 329.63, 349.23, 523.25], // F3, C4, E4, F4, C5
      [110.00, 220.00, 293.66, 329.63, 440.00, 587.33], // A2, A3, D4, E4, A4, D5 (Am9)
      [196.00, 293.66, 392.00, 440.00, 587.33], // G3, D4, G4, A4, D5
      [164.81, 246.94, 311.13, 392.00, 493.88]  // E3, B3, Eb4, G4, B4
    ];

    const playChord = () => {
      if (!this.ctx || !this.masterGain || this.activeMode !== "Rain") return;

      const now = this.ctx.currentTime;
      const index = Math.floor(Math.random() * chords.length);
      const chord = chords[index];

      // Delay notes slightly (arpeggio) to simulate a real human fingers touching piano keys
      chord.forEach((freq, idx) => {
        const osc = this.ctx!.createOscillator();
        const gain = this.ctx!.createGain();
        const filter = this.ctx!.createBiquadFilter();

        osc.type = "sine"; // warmer piano sound
        osc.frequency.value = freq;

        filter.type = "lowpass";
        filter.frequency.setValueAtTime(600, now);
        filter.frequency.exponentialRampToValueAtTime(100, now + 5);

        const arpDelay = idx * 0.15;
        gain.gain.setValueAtTime(0, now + arpDelay);
        gain.gain.linearRampToValueAtTime(0.03 / chord.length, now + arpDelay + 0.1); 
        gain.gain.exponentialRampToValueAtTime(0.00001, now + arpDelay + 7.0); // 7 seconds beautiful reverb release

        osc.connect(filter);
        filter.connect(gain);
        gain.connect(this.masterGain!);

        osc.start(now + arpDelay);
        osc.stop(now + arpDelay + 8.0);
      });

      const delay = Math.random() * 6000 + 9000; // random 9-15 seconds
      this.chordTimer = setTimeout(playChord, delay);
    };

    this.chordTimer = setTimeout(playChord, 1500);
  }

  // Scheduler simulating distant thunderstorm rolling rumbler
  private startThunderGenerator() {
    const playThunder = () => {
      if (!this.ctx || !this.masterGain || this.activeMode !== "Thunderstorm") return;

      const now = this.ctx.currentTime;
      
      // Low rumble noise
      const bufferSize = this.ctx.sampleRate * 5; // 5 seconds rumble
      const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        data[i] = Math.random() * 2 - 1;
      }

      const source = this.ctx.createBufferSource();
      source.buffer = buffer;

      const lowpass = this.ctx.createBiquadFilter();
      lowpass.type = "lowpass";
      lowpass.frequency.setValueAtTime(60, now);
      lowpass.frequency.linearRampToValueAtTime(30, now + 4);

      const gain = this.ctx.createGain();
      gain.gain.setValueAtTime(0, now);
      gain.gain.linearRampToValueAtTime(0.08, now + 0.8); // slow rumble hit
      gain.gain.linearRampToValueAtTime(0.02, now + 2); // rolling tails
      gain.gain.exponentialRampToValueAtTime(0.00001, now + 5.0);

      // rumble shaking frequency modulator LFO
      const shake = this.ctx.createOscillator();
      const shakeGain = this.ctx.createGain();
      shake.frequency.value = 12; // 12Hz rumble shakiness
      shakeGain.gain.value = 10;
      shake.connect(shakeGain);
      shakeGain.connect(lowpass.frequency);
      shake.start();

      source.connect(lowpass);
      lowpass.connect(gain);
      gain.connect(this.masterGain);

      source.start(now);
      source.stop(now + 5.1);

      const delay = Math.random() * 12000 + 13000; // 13-25 seconds thunder intervals
      this.chordTimer = setTimeout(playThunder, delay);
    };

    this.chordTimer = setTimeout(playThunder, 5000);
  }

  // Train rhythm click soundscape scheduler
  private startTrainRhythm() {
    const playClick = () => {
      if (!this.ctx || !this.masterGain || this.activeMode !== "Night Train") return;

      const now = this.ctx.currentTime;

      // Click clack: thump-clink thump-clink
      const scheduleClick = (timeOffset: number, volMultiplier: number) => {
        const osc = this.ctx!.createOscillator();
        const gain = this.ctx!.createGain();
        const filter = this.ctx!.createBiquadFilter();

        osc.type = "triangle";
        osc.frequency.setValueAtTime(50, now + timeOffset); // very low thump
        osc.frequency.setValueAtTime(70, now + timeOffset + 0.05);

        filter.type = "lowpass";
        filter.frequency.value = 80;

        gain.gain.setValueAtTime(0, now + timeOffset);
        gain.gain.linearRampToValueAtTime(0.008 * volMultiplier, now + timeOffset + 0.01);
        gain.gain.exponentialRampToValueAtTime(0.00001, now + timeOffset + 0.15);

        osc.connect(filter);
        filter.connect(gain);
        gain.connect(this.masterGain!);

        osc.start(now + timeOffset);
        osc.stop(now + timeOffset + 0.2);
      };

      // Dual clicking representing wheels
      scheduleClick(0.0, 1.0);     // Ka-
      scheduleClick(0.12, 0.7);    // chunk...
      scheduleClick(0.4, 0.85);    // ka-
      scheduleClick(0.52, 0.5);    // chunk...

      const delay = 1800; // rhythmic beats of wheels
      this.trainTimer = setTimeout(playClick, delay);
    };

    this.trainTimer = setTimeout(playClick, 500);
  }

  // Moving soft warm cloud atmospheric swells for "Calm Air Mode"
  private startCalmAirSwells() {
    const chordNotes = [220.0, 277.18, 329.63, 392.00, 440.0]; // A3, C#4, E4, G4, A4 (Am/A9)
    
    const triggerSwell = () => {
      if (!this.ctx || !this.masterGain || this.activeMode !== "Calm Air") return;

      const now = this.ctx.currentTime;
      const note = chordNotes[Math.floor(Math.random() * chordNotes.length)];

      const osc1 = this.ctx.createOscillator();
      const osc2 = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const filter = this.ctx.createBiquadFilter();

      // Slow sweeping bandpass filter simulating dawn mist lifting
      filter.type = "bandpass";
      filter.Q.value = 1.0;
      filter.frequency.setValueAtTime(200, now);
      filter.frequency.linearRampToValueAtTime(800, now + 4.0);
      filter.frequency.linearRampToValueAtTime(200, now + 8.0);

      osc1.type = "triangle";
      osc1.frequency.value = note;
      osc2.type = "triangle";
      osc2.frequency.value = note * 1.005; // slightly chorused detuning

      gain.gain.setValueAtTime(0, now);
      gain.gain.linearRampToValueAtTime(0.018, now + 3.5); // very slow attack
      gain.gain.linearRampToValueAtTime(0.018, now + 5.0); // hold
      gain.gain.exponentialRampToValueAtTime(0.00001, now + 10.0); // long release

      osc1.connect(filter);
      osc2.connect(filter);
      filter.connect(gain);
      gain.connect(this.masterGain);

      osc1.start(now);
      osc2.start(now);
      osc1.stop(now + 10.5);
      osc2.stop(now + 10.5);

      const delay = 7000; // overlapping waves
      this.trainTimer = setTimeout(triggerSwell, delay);
    };

    this.trainTimer = setTimeout(triggerSwell, 1000);
  }

  private stopTimers() {
    if (this.chimeTimer) clearTimeout(this.chimeTimer);
    if (this.chordTimer) clearTimeout(this.chordTimer);
    if (this.trainTimer) clearTimeout(this.trainTimer);
  }

  public setVolume(vol: number) {
    this.currentVolume = vol;
    localStorage.setItem("brother_ambient_volume", vol.toString());
    
    if (this.ctx && this.masterGain && !this.currentMuted) {
      this.masterGain.gain.setValueAtTime(this.masterGain.gain.value, this.ctx.currentTime);
      this.masterGain.gain.linearRampToValueAtTime(vol, this.ctx.currentTime + 0.1);
    }
  }

  public setMuted(muted: boolean) {
    this.currentMuted = muted;
    localStorage.setItem("brother_ambient_muted", muted ? "true" : "false");
    
    if (this.ctx && this.masterGain) {
      const targetVol = muted ? 0 : this.currentVolume;
      this.masterGain.gain.setValueAtTime(this.masterGain.gain.value, this.ctx.currentTime);
      this.masterGain.gain.linearRampToValueAtTime(targetVol, this.ctx.currentTime + 0.2);
    }
  }

  public resumeContext() {
    if (this.ctx && this.ctx.state === "suspended") {
      this.ctx.resume();
    }
  }

  public getVolume() { return this.currentVolume; }
  public getMuted() { return this.currentMuted; }
}

export const audioManager = new AmbientAudioEngine();
